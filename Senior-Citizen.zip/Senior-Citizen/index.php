<!DOCTYPE html>

<html>
<head>

<title>Senior Citizen Information System</title>

<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
background:#f5f7fa;
font-family: Arial, Helvetica, sans-serif;
}

.hero{
background: linear-gradient(135deg,#0d6efd,#0a58ca);
color:white;
padding:70px 20px;
text-align:center;
}

.section{
padding:50px 20px;
}

.footer{
background:#343a40;
color:white;
padding:20px;
text-align:center;
}

.card{
border:none;
}

</style>

</head>

<body>

<!-- HERO / HEADER -->

<div class="hero">

<img src="images/orion_logo.png" width="90" class="mb-3">

<h1 class="fw-bold">Senior Citizen Information System</h1>

<h4>Municipality of Orion, Bataan</h4>

<p class="mt-3">
A web-based system designed to improve the recording, monitoring,
reporting, and online registration of senior citizen information.
</p>

<a href="register_senior.php" class="btn btn-light btn-lg m-2">
Apply for Senior Citizen Registration
</a>

<a href="login.php" class="btn btn-warning btn-lg m-2">
Staff Login
</a>

</div>

<!-- ABOUT SYSTEM -->

<div class="container section">

<div class="row">

<div class="col-md-6">

<h3>About the System</h3>

<p>
The Senior Citizen Information System for the Municipality of Orion
is developed to assist the Office of Senior Citizens Affairs (OSCA)
in organizing and managing records of registered senior citizens.
</p>

<p>
The system allows online registration, organized record management,
monitoring of senior citizen status, generation of reports,
and dissemination of announcements related to senior citizen programs.
</p>

</div>

<div class="col-md-6">

<h3>System Features</h3>

<ul class="list-group">

<li class="list-group-item">Online Registration for Senior Citizens</li>

<li class="list-group-item">Senior Citizen Records Management</li>

<li class="list-group-item">Monitoring of Active and Deceased Seniors</li>

<li class="list-group-item">Reports and Data Summary</li>

<li class="list-group-item">Announcements and Program Updates</li>

</ul>

</div>

</div>

</div>

<!-- REQUIREMENTS -->

<div class="container section">

<h3 class="text-center mb-4">Registration Requirements</h3>

<div class="row text-center">

<div class="col-md-4">
<div class="card shadow-sm">
<div class="card-body">
<h5>Age Requirement</h5>
<p>Applicant must be sixty (60) years old and above.</p>
</div>
</div>
</div>

<div class="col-md-4">
<div class="card shadow-sm">
<div class="card-body">
<h5>Proof of Residency</h5>
<p>Applicant must be a resident of the Municipality of Orion.</p>
</div>
</div>
</div>

<div class="col-md-4">
<div class="card shadow-sm">
<div class="card-body">
<h5>Valid Identification</h5>
<p>Valid ID or birth certificate may be required for verification.</p>
</div>
</div>
</div>

</div>

</div>

<!-- SENIOR PROGRAMS -->

<div class="container section">

<h3 class="text-center mb-4">Senior Citizen Programs</h3>

<div class="row">

<div class="col-md-4">
<div class="card shadow-sm">
<div class="card-body">
<h5>Social Pension</h5>
<p>Financial assistance provided to indigent senior citizens.</p>
</div>
</div>
</div>

<div class="col-md-4">
<div class="card shadow-sm">
<div class="card-body">
<h5>Medical Assistance</h5>
<p>Priority access to healthcare services and medical support.</p>
</div>
</div>
</div>

<div class="col-md-4">
<div class="card shadow-sm">
<div class="card-body">
<h5>Community Activities</h5>
<p>Participation in wellness, social, and recreational activities.</p>
</div>
</div>
</div>

</div>

</div>

<!-- CONTACT -->

<div class="container section">

<div class="row text-center">

<h3 class="mb-4">Office of Senior Citizens Affairs</h3>

<div class="col-md-4">
<h5>Municipality</h5>
<p>Municipality of Orion</p>
</div>

<div class="col-md-4">
<h5>Office</h5>
<p>Office for Senior Citizens Affairs (OSCA)</p>
</div>

<div class="col-md-4">
<h5>Services</h5>
<p>Registration, Records Management, Senior Programs</p>
</div>

</div>

</div>

<!-- FOOTER -->

<div class="footer">

<p>
Senior Citizen Information System © 2026  
Municipality of Orion, Bataan
</p>

</div>

</body>
</html>
