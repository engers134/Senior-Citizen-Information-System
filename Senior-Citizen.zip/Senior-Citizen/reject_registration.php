<?php

include "config.php";
include "send_email.php";

/* FIX: DEFINE ID FIRST */
$id = $_GET['id'];

/* GET DATA */
$data = $conn->query("SELECT * FROM pending_registrations WHERE id='$id'")->fetch_assoc();

/* GET EMAIL */
$email = $data['email'];

/* EMAIL CONTENT */
$subject = "Senior Citizen Registration Update";

$message = "
Dear ".$data['fname'].",

We regret to inform you that your application has been <b>REJECTED</b>.

Please visit the OSCA office for further assistance.

Thank you.
";

/* SEND EMAIL */
sendEmail($email, $subject, $message);

/* UPDATE STATUS */
$conn->query("UPDATE pending_registrations SET status='Rejected' WHERE id='$id'");

/* REDIRECT */
header("Location: pending_applications.php");
exit();

?>
