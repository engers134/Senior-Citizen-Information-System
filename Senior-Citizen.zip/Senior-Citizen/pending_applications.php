<?php
include "session_check.php";
include "config.php";

$limit = 10; // records per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;
$search = isset($_GET['search']) ? $_GET['search'] : '';
?>

<!DOCTYPE html>
<html>
<head>

<title>Pending Applications</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
.sidebar { min-height:100vh; }
.nav-link:hover { background:#495057; }

.table th, .table td {
    vertical-align: middle;
}
</style>

</head>

<body class="bg-light">

<div class="container-fluid">
<div class="row">

<?php include "sidebar.php"; ?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">

<!-- HEADER -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Pending Applications</h2>
</div>

<!-- SEARCH -->
<form method="GET" class="row mb-3">
    <div class="col-md-4">
        <input type="text" name="search" class="form-control"
        placeholder="Search by name..."
        value="<?php echo $search; ?>">
    </div>

    <div class="col-md-3">
        <button class="btn btn-primary">Search</button>
        <a href="pending_applications.php" class="btn btn-secondary">Reset</a>
    </div>
</form>

<!-- CARD -->
<div class="card shadow-sm">
<div class="card-body">

<div class="table-responsive">

<table class="table table-bordered table-hover align-middle text-center">

<thead class="table-dark">
<tr>
<th>Name</th>
<th>Barangay</th>
<th>Contact</th>
<th>Date Applied</th>
<th>Action</th>
</tr>
</thead>

<tbody>

<?php
$where = "WHERE status='Pending'";

if($search != ''){
    $where .= " AND (
        lname LIKE '%$search%' OR
        fname LIKE '%$search%'
    )";
}

$result = $conn->query("
SELECT pending_registrations.*, barangay.name AS barangay_name
FROM pending_registrations
LEFT JOIN barangay ON pending_registrations.barangay_id = barangay.id
$where
ORDER BY pending_registrations.id DESC
LIMIT $start, $limit
");

$total_result = $conn->query("
SELECT COUNT(*) as total 
FROM pending_registrations
$where
");

$total_row = $total_result->fetch_assoc();
$total_records = $total_row['total'];
$total_pages = ceil($total_records / $limit);

/* ✅ FIX: ADD CONDITION */
if($result->num_rows > 0){

    while($row = $result->fetch_assoc()){
?>

<tr>
    <td class="text-start">
        <?php echo $row['lname'].", ".$row['fname']; ?>
    </td>
    <td><?php echo $row['barangay_name']; ?></td>
    <td><?php echo $row['contact_info']; ?></td>
    <td><?php echo $row['date_applied']; ?></td>

    <td>
        <div class="d-flex justify-content-center gap-2">
            <a href="view_pending.php?id=<?php echo $row['id']; ?>" class="btn btn-info btn-sm">View</a>
            <a href="approve_registration.php?id=<?php echo $row['id']; ?>" class="btn btn-success btn-sm">Approve</a>
            <a href="reject_registration.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Reject</a>
        </div>
    </td>
</tr>

<?php
    }

}else{
?>

<tr>
    <td colspan="5" class="text-center text-muted">
        No results found<?php if($search) echo " for \"$search\""; ?>
    </td>
</tr>

<?php
}
?>

</tbody>

</table>

</div>

<!-- PAGINATION -->
<div class="mt-4 d-flex justify-content-center">

<nav>
<ul class="pagination">

<?php if($page > 1){ ?>
<li class="page-item">
<a class="page-link" href="?page=<?php echo $page-1; ?>&search=<?php echo $search; ?>">Previous</a>
</li>
<?php } ?>

<?php for($i=1; $i<=$total_pages; $i++){ ?>
<li class="page-item <?php if($i==$page) echo 'active'; ?>">
<a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo $search; ?>">
<?php echo $i; ?>
</a>
</li>
<?php } ?>

<?php if($page < $total_pages){ ?>
<li class="page-item">
<a class="page-link" href="?page=<?php echo $page+1; ?>&search=<?php echo $search; ?>">Next</a>
</li>
<?php } ?>

</ul>
</nav>

</div>

</div>
</div>

</main>

</div>
</div>

</body>
</html>