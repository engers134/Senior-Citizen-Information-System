<?php
include "config.php";


if($_SERVER["REQUEST_METHOD"] == "POST"){

$lname = $_POST['lname'];
$fname = $_POST['fname'];
$mname = $_POST['mname'];
$extension = $_POST['extension'];
$gender = $_POST['gender'];
$civil_status = $_POST['civil_status'];
$birthdate = $_POST['birthdate'];
$birth_place = $_POST['birth_place'];

$barangay_id = $_POST['barangay_id']; // ✅ CORRECT

$address = $_POST['address'];
$contact = $_POST['contact_info'];
$email = $_POST['email'];
$pension = $_POST['pension_status'];
$monthly = $_POST['monthly_pension'];
$education = $_POST['education'];
$occupation = $_POST['occupation'];
$em_person = $_POST['em_person'];
$em_number = $_POST['em_number'];
$em_address = $_POST['em_address'];

/* ✅ INSERT TO PENDING TABLE */

$sql = "INSERT INTO pending_registrations
(lname,fname,mname,extension,gender,civil_status,birthdate,birth_place,barangay_id,address,contact_info,email,pension_status,monthly_pension,education,occupation,em_person,em_number,em_address,status,date_applied)

VALUES
('$lname','$fname','$mname','$extension','$gender','$civil_status','$birthdate','$birth_place','$barangay_id','$address','$contact','$email','$pension','$monthly','$education','$occupation','$em_person','$em_number','$em_address','Pending',NOW())";

if(!$conn->query($sql)){
    die("SQL ERROR: " . $conn->error);
}

// ✅ IMPORTANT: GET LAST INSERTED ID HERE
$last_id = $conn->insert_id;


/* ✅ SAVE FAMILY MEMBERS */

if(isset($_POST['family_name'])){


for($i=0; $i<count($_POST['family_name']); $i++){

$name = $_POST['family_name'][$i];
$rel = $_POST['relationship'][$i];
$age = $_POST['family_age'][$i];
$civil = $_POST['family_civil'][$i];
$occ = $_POST['family_occupation'][$i];
$inc = $_POST['family_income'][$i];

if($name != ""){

$conn->query("INSERT INTO pending_family
(pending_id,name,relationship,age,civil_status,occupation,income)
VALUES
('$last_id','$name','$rel','$age','$civil','$occ','$inc')");

}

}

}

/* REDIRECT */

header("Location: register_senior.php?success=1");
exit();

}
?>

