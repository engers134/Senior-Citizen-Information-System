<?php
include "session_check.php";
include "config.php";

$id = $_GET['id'];

$data = $conn->query("
SELECT pending_registrations.*, barangay.name AS barangay_name
FROM pending_registrations
LEFT JOIN barangay ON pending_registrations.barangay_id = barangay.id
WHERE pending_registrations.id='$id'
")->fetch_assoc();


?>

<!DOCTYPE html>

<html>
<head>

<title>View Application</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-4">

<a href="pending_applications.php" class="btn btn-secondary mb-3">← Back</a>

<div class="card shadow">
<div class="card-body">

<h4>Applicant Details</h4>

<hr>

<p><strong>Name:</strong> <?php echo $data['lname'].", ".$data['fname']." ".$data['mname']; ?></p>
<p><strong>Gender:</strong> <?php echo $data['gender']; ?></p>
<p><strong>Civil Status:</strong> <?php echo $data['civil_status']; ?></p>
<p><strong>Birthdate:</strong> <?php echo $data['birthdate']; ?></p>
<p><strong>Place of Birth:</strong> <?php echo $data['birth_place']; ?></p>

<hr>

<p><strong>Barangay:</strong> <?php echo $data['barangay_name']; ?></p>
<p><strong>Address:</strong> <?php echo $data['address']; ?></p>
<p><strong>Contact:</strong> <?php echo $data['contact_info']; ?></p>
<p><strong>Email Address:</strong> <?php echo $data['email']; ?></p>

<hr>

<p><strong>Pension:</strong> <?php echo $data['pension_status']; ?></p>
<p><strong>Monthly:</strong> <?php echo $data['monthly_pension']; ?></p>

<hr>

<p><strong>Education:</strong> <?php echo $data['education']; ?></p>
<p><strong>Occupation:</strong> <?php echo $data['occupation']; ?></p>

<hr>

<h5>Family Composition</h5>

<table class="table table-bordered">
<tr>
<th>Name</th>
<th>Relationship</th>
<th>Age</th>
<th>Civil Status</th>
<th>Occupation</th>
<th>Income</th>
</tr>

<?php

$fam = $conn->query("SELECT * FROM pending_family WHERE pending_id='$id'");

while($f = $fam->fetch_assoc()){

echo "<tr>";
echo "<td>".$f['name']."</td>";
echo "<td>".$f['relationship']."</td>";
echo "<td>".$f['age']."</td>";
echo "<td>".$f['civil_status']."</td>";
echo "<td>".$f['occupation']."</td>";
echo "<td>".$f['income']."</td>";
echo "</tr>";

}

?>

</table>

<hr>

<h5>Emergency Contact</h5>

<p><strong>Name:</strong> <?php echo $data['em_person']; ?></p>
<p><strong>Contact:</strong> <?php echo $data['em_number']; ?></p>
<p><strong>Address:</strong> <?php echo $data['em_address']; ?></p>

</div>
</div>

</div>

</body>
</html>
