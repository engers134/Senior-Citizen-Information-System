/*
SQLyog Enterprise - MySQL GUI v8.18 
MySQL - 5.5.5-10.1.31-MariaDB : Database - scims_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`scims_db` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `scims_db`;

/*Table structure for table `barangay` */

DROP TABLE IF EXISTS `barangay`;

CREATE TABLE `barangay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `contact_person_number` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

/*Data for the table `barangay` */

insert  into `barangay`(`id`,`name`,`contact`,`email`,`contact_person`,`contact_person_number`) values (11,'Arellano (Poblacion)','2','trial@gmail.com','SEC.','1'),(12,'Bagumbayan (Poblacion)','1','trial@gmail.com','SEC.','1'),(13,'Balagtas (Poblacion)','1','trial@gmail.com','SEC.','1'),(14,'Balut (Poblacion)','1','trial@gmail.com','SEC.','1'),(15,'Bantan','1','trial@gmail.com','SEC.','1'),(16,'Bilolo','1','trial@gmail.com','SEC.','1'),(17,'Calungusan','1','trial@gmail.com','SEC.','1'),(18,'Camachile','1','trial@gmail.com','SEC.','1'),(19,'Daang Bago (Poblacion)','1','trial@gmail.com','SEC.','1'),(20,'Daang Bilolo (Poblacion)','1','trial@gmail.com','SEC.','1'),(21,'Daang Pare','1','trial@gmail.com','SEC.','1'),(22,'General Lim (Kapunitan)','1','trial@gmail.com','SEC.','1'),(23,'Kapunitan','1','trial@gmail.com','SEC.','1'),(24,'Lati (Poblacion)','1','trial@gmail.com','SEC.','1'),(25,'Lusungan (Poblacion)','1','trial@gmail.com','SEC.','1'),(26,'Puting Buhangin','1','trial@gmail.com','SEC.','1'),(27,'Sabatan','1','trial@gmail.com','SEC.','1'),(28,'San Vicente (Poblacion)','1','trial@gmail.com','SEC.','1'),(29,'Santa Elena','1','trial@gmail.com','SEC.','1'),(30,'Santo Domingo','1','trial@gmail.com','SEC.','1'),(31,'Villa Angeles (Poblacion)','1','trial@gmail.com','SEC.','1'),(32,'Wakas (Poblacion)','1','trial@gmail.com','SEC.','1'),(33,'Wawa (Poblacion) ','1','trial@gmail.com','SEC.','1');

/*Table structure for table `family_composition` */

DROP TABLE IF EXISTS `family_composition`;

CREATE TABLE `family_composition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `senior_id` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `relationship` varchar(50) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `civil_status` varchar(50) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `income` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `senior_id` (`senior_id`),
  CONSTRAINT `family_composition_ibfk_1` FOREIGN KEY (`senior_id`) REFERENCES `senior_citizens` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;

/*Data for the table `family_composition` */

insert  into `family_composition`(`id`,`senior_id`,`name`,`relationship`,`age`,`civil_status`,`occupation`,`income`) values (37,73,'THYLAINE MAGSINO','MOTHERs',3,'Single','N/A','0.00'),(38,75,'SAD','ADAS',1,'Single','N/A','0.00'),(39,73,'sdasdas','sda',11,'Single','','0.00'),(40,77,'AAAA','AAA',1,'Single','N/A','0.00'),(41,79,'sadsa','dasd',1,'Single','n/a','0.00'),(42,85,'dasdas','asd',1,'Single','','0.00'),(43,94,'WALA','SISTER',12,'Single','','0.00'),(44,94,'MERON','SISTER',12,'Married','DOCTOR','10000.00'),(45,94,'SAME','BROTHER',18,'Single','N/A','0.00'),(46,95,'DSADA','DA',1,'Single','','0.00'),(47,96,'SADADA','ASDASDSA',1,'Single','SADAD','111.00'),(48,97,'sda','daasd',1,'Single','sada','0.00'),(49,98,'SADA','DADA',1,'Single','DSADA','1.00'),(50,99,'sada','sadada',1,'Single','asd','0.00'),(51,100,'MARIAN RIVERA','WIFE',40,'Married','ARTIST','10000.00'),(52,101,'ALMON BALUENA','SON',1,'Single','N/A','0.00'),(53,102,'SADSA','DAS',1,'Single','SAD','0.00'),(54,102,'DASDA','ASDADA',2,'Married','SAD','0.00'),(55,103,'','',0,'Single','','0.00'),(56,104,'sdad','addaas',1,'Single','','0.00'),(57,105,'xzczc','zczc',1,'Single','zsczxc','0.00'),(58,107,'','',0,'Single','','0.00'),(59,108,'','',0,'Single','','0.00'),(60,109,'LAYLA FORD','SISTER',12,'Single','N/A','0.00'),(61,110,'dsad','sada',1,'Single','sada','1.00');

/*Table structure for table `pending_family` */

DROP TABLE IF EXISTS `pending_family`;

CREATE TABLE `pending_family` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pending_id` int(11) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `relationship` varchar(100) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `civil_status` varchar(50) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `income` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

/*Data for the table `pending_family` */

insert  into `pending_family`(`id`,`pending_id`,`name`,`relationship`,`age`,`civil_status`,`occupation`,`income`) values (1,1,'asda','asda',1,'Single','','0.00'),(2,1,'sdadasda','asda',2,'Married','','0.00'),(3,2,'JOJO MAGSINO','ANAK',19,'Single','','0.00'),(4,3,'WALA','SISTER',12,'Single','','0.00'),(5,3,'MERON','SISTER',12,'Married','DOCTOR','10000.00'),(6,3,'SAME','BROTHER',18,'Single','N/A','0.00'),(7,4,'DSADA','DA',1,'Single','','0.00'),(8,5,'SADADA','ASDASDSA',1,'Single','SADAD','111.00'),(9,6,'ASDA','ASDAD',1,'Single','ASD','0.00'),(10,7,'sda','daasd',1,'Single','sada','0.00'),(11,8,'SADA','DADA',1,'Single','DSADA','1.00'),(12,9,'sada','sadada',1,'Single','asd','0.00'),(13,10,'MARIAN RIVERA','WIFE',40,'Married','ARTIST','10000.00'),(14,11,'ALMON BALUENA','SON',1,'Single','N/A','0.00'),(15,12,'SADSA','DAS',1,'Single','SAD','0.00'),(16,12,'DASDA','ASDADA',2,'Married','SAD','0.00'),(17,0,'sdad','sda',1,'Single','sada','0.00'),(18,13,'asdada','daa',1,'Single','asda','1.00'),(19,14,'','',0,'Single','','0.00'),(20,15,'sadas','asdasda',1,'Single','1','0.00'),(21,16,'sdad','addaas',1,'Single','','0.00'),(22,17,'daczcz','zcxczc',1,'Single','sdad','111.00'),(23,18,'sadasd','asda',1,'Single','asdasd','1.00'),(24,19,'xzczc','zczc',1,'Single','zsczxc','0.00'),(25,20,'','',0,'Single','','0.00'),(26,21,'','',0,'Single','','0.00'),(27,22,'LAYLA FORD','SISTER',12,'Single','N/A','0.00'),(28,23,'dsad','sada',1,'Single','sada','1.00');

/*Table structure for table `pending_registrations` */

DROP TABLE IF EXISTS `pending_registrations`;

CREATE TABLE `pending_registrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lname` varchar(100) DEFAULT NULL,
  `fname` varchar(100) DEFAULT NULL,
  `mname` varchar(100) DEFAULT NULL,
  `extension` varchar(20) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `civil_status` varchar(50) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `birth_place` varchar(150) DEFAULT NULL,
  `barangay` varchar(150) DEFAULT NULL,
  `address` text,
  `contact_info` varchar(50) DEFAULT NULL,
  `pension_status` varchar(50) DEFAULT NULL,
  `monthly_pension` decimal(10,2) DEFAULT NULL,
  `education` varchar(150) DEFAULT NULL,
  `occupation` varchar(150) DEFAULT NULL,
  `em_person` varchar(150) DEFAULT NULL,
  `em_number` varchar(50) DEFAULT NULL,
  `em_address` text,
  `status` varchar(50) DEFAULT 'Pending',
  `date_applied` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `email` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

/*Data for the table `pending_registrations` */

insert  into `pending_registrations`(`id`,`lname`,`fname`,`mname`,`extension`,`gender`,`civil_status`,`birthdate`,`birth_place`,`barangay`,`address`,`contact_info`,`pension_status`,`monthly_pension`,`education`,`occupation`,`em_person`,`em_number`,`em_address`,`status`,`date_applied`,`email`) values (1,'sadad','sadad','sadas','Sr.','Male','Single','1940-10-10','sdadad','Camachile','sdadasd','1','With Pension','1.00','asda','dsa','sdada','1','asda','Approved','2026-03-17 14:41:36',NULL),(2,'MAGSINO','DOLORES','MACAPINLAC','','Female','Widowed','1946-05-10','PAMPANGA','Santo Domingo','ORION BATAAN','1','Without Pension','0.00','COLLEGE','NURSE','DALE MAGSINO','1','LIMAY','Approved','2026-03-17 15:03:13',NULL),(3,'SILVA','SAHRA','SANTIAGO','','Female','Single','1946-10-10','LIMAY','Daang Bago (Pob.)','ORION BATAAN','123456','With Pension','0.00','COLLEGE','NURSE','SINO NGA BA','1','LIMAY','Approved','2026-03-17 15:15:08',NULL),(4,'JAKE ','ALBERT','ASDADADS','','Male','Widowed','1946-10-10','SDASAD','Kapunitan','ADSSADA','1','With Pension','111.00','SDSADA','DADADAD','ASDA','1','DASDAD','Approved','2026-03-17 15:21:07',NULL),(5,'ADSON','ADSON','ASDADA','','Male','Married','1945-12-12','SADAD','Daang Bago (Pob.)','SDADAD','1','Without Pension','0.00','SDADSA','DSAD','DSADA','1','SADA','Approved','2026-03-17 15:25:08',NULL),(6,'SHIELA','SHIELA','DSADSAD','Sr.','Male','Married','1970-10-10','SADAD','Sabatan','SADAD','1','With Pension','1111.00','SDASD','ASDAD','SDADA','1','ASDASD','Rejected','2026-03-17 15:27:27',NULL),(7,'jajajajaja','asdssadada','sadada','','Male','Married','1945-10-10','asdsada','Daang Bilolo (Pob.)','sdad','1','With Pension','111.00','asdas','dsad','sada','1','dsadad','Approved','2026-03-17 15:42:16',NULL),(8,'MICHAEL','SOLOMON','SADASD','','Male','Widowed','1945-12-12','SADAD','Daang Bilolo (Pob.)','SDAAD','1','With Pension','1111.00','SADA','DDSA','ASDA','1','ASDA','Approved','2026-03-17 15:52:16',NULL),(9,'CRIS','CRIS','asdsadas','','Male','Married','1970-10-10','adads','Lati (Pob.)','dasda','`','With Pension','111.00','sada','dada','adsasd','1','asdas','Approved','2026-03-17 15:59:41',NULL),(10,'DANTES','DING-DONG','KURIMAW','','Male','Married','1940-10-10','MANILA','San Vicente (Pob.)','ORION BATAAN','09213644279','Without Pension','0.00','COLLEGE','ARTIST','JULIAN PONTES','09442123152','LIMAY','Approved','2026-03-17 16:52:26',NULL),(11,'BALBUENA','ALDRIN','CRUZ','','Male','Married','1948-11-04','MANILA','Santo Domingo','ORION BATAAN','12115445515','With Pension','10000.00','COLLEGE','POLICE','JOMAG POGI','122324','LIMAY','Approved','2026-03-17 21:29:35',NULL),(12,'YAYAY','YAYAYAYA','WALA','II','Female','Married','1946-10-10','SDADSA','Bilolo','SADADSA','1','Without Pension','0.00','SADSAD','SADADA','SDADSA','1','ASDA','Approved','2026-03-17 21:39:00',NULL),(13,'LANDICHO','AIZA','SADADA','','Female','Married','1970-10-10','SADASDADA','Kapunitan','SADSADSADSA','121313','Without Pension','0.00','dsada','dasdsa','sdada','1','asdsad','Rejected','2026-03-17 22:30:55','engersonlinegames134@gmail.com'),(14,'SASA','SALMON','ASDADADSA','','Female','Married','1940-10-10','ASDASDSA','Camachile','SADADA','1','Without Pension','0.00','dsadsada','da','sdadaad','1','asdsadas','Approved','2026-03-17 22:35:38','engersonlinegames134@gmail.com'),(15,'dahon','dahon','dsadsada','','Male','Single','1940-11-01','sadasdsa','Lati (Pob.)','dsadasdsa','1','Without Pension','0.00','sdad','adas','sadsa','1','sdasda','Rejected','2026-03-17 22:45:52','engersonlinegames134@gmail.com'),(16,'sadasdasdadasdadasdas','kiki','asasda','','Female','Married','1940-10-10','sdasda','Daang Pare','sada','1','With Pension','1111.00','sdasd','sadas','sdad','1','asdasda','Approved','2026-03-17 22:48:08','jojomagsino0122@gmail.com'),(17,'fsdfsfsdsfsdsdfs','dale','asddadad','','Female','Married','1940-10-10','sdasdas','Kapunitan','dasdasda','1','With Pension','111.00','asdas','adsad','asdada','1','asdasd','Rejected','2026-03-17 22:50:20','jojokulit10@gmail.com'),(18,'sdadasdas','THYALINE','SADASDAS','','Female','Married','1940-10-10','SADASDSA','Lusungan (Pob.)','ASDASDAS','1','Without Pension','0.00','dsadsa','sdaasd','sadada','1','sadasda','Rejected','2026-03-17 22:57:16','engersonlinegames134@gmail.com'),(19,'CRUZ','GENESIS','MAMAMA','','Male','Separated','1940-10-10','MANILA','Lati (Pob.)','SADASDASD','1','With Pension','111.00','zczcz','zcxzc','zczczxc','1','cxzcxzcxzcz','Approved','2026-03-18 08:49:54','flashbackstv@gmail.com'),(20,'sadsadsa','dsadsadas','sadsadsa','','Male','Married','1945-12-12','sadwasd','General Lim (Kaput)','sdada','sadadsa','With Pension','1.00','sadad','dasda','asdsad','1','sdsad','Approved','2026-03-18 09:37:52','sad@gmail.com'),(21,'SOLEM','SOLEM','SADADA','','Male','Married','1940-12-12','ASDASD','Kapunitan','SADASD','ASD','With Pension','1.00','SADAD','ASDA','ASDSA','D1','ASDAD','Approved','2026-03-18 09:46:23','jomags1001@gmail.com'),(22,'GLORIA','EMMANUEL','NATIVIDAD','','Male','Married','1942-10-10','ORION','General Lim (Kaput)','ORION BATAAN','1213','Without Pension','0.00','COLLEGE','POLICE','ALING NENE','313423','LIMAY','Approved','2026-03-18 10:20:07','jojokulit10@gmail.com'),(23,'dsadas','dsadasdsad','asdsadsada','','Male','Married','1940-12-10','asdasdasd','Wawa (Pob.)','sadsadadad','sadadasda','With Pension','0.00','sadasd','dasda','sadsada','111','sdadsadas','Approved','2026-03-18 10:33:56','engersonlinegame134@gmail.com');

/*Table structure for table `senior_citizens` */

DROP TABLE IF EXISTS `senior_citizens`;

CREATE TABLE `senior_citizens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sc_id` varchar(50) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `extension` varchar(10) DEFAULT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `civil_status` varchar(50) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `birth_place` varchar(150) DEFAULT NULL,
  `address` text,
  `contact_info` varchar(100) DEFAULT NULL,
  `barangay_id` int(11) DEFAULT NULL,
  `pension_status` varchar(20) DEFAULT NULL,
  `monthly_pension` decimal(10,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `emergency_person` varchar(150) DEFAULT NULL,
  `emergency_number` varchar(50) DEFAULT NULL,
  `emergency_address` text,
  `education` varchar(100) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `date_of_death` date DEFAULT NULL,
  `encoded_by` int(11) DEFAULT NULL,
  `date_encoded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `email` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=latin1;

/*Data for the table `senior_citizens` */

insert  into `senior_citizens`(`id`,`sc_id`,`last_name`,`first_name`,`extension`,`middle_name`,`gender`,`civil_status`,`birthdate`,`age`,`birth_place`,`address`,`contact_info`,`barangay_id`,`pension_status`,`monthly_pension`,`status`,`emergency_person`,`emergency_number`,`emergency_address`,`education`,`occupation`,`date_of_death`,`encoded_by`,`date_encoded`,`email`) values (72,'SC-2026-0001','MAGSINO','ENGERS','','MACAPINLAC','Male','Married','1970-10-01',55,'PAMPANGA','ORION BATAAN','09213644279',27,'Without Pension','0.00','Active','LAUDER DALE MAGSINO','12331233','BALANGA BATAAN','COLLEGE','POLICE','0000-00-00',NULL,'2026-03-16 10:48:58',NULL),(73,'SC-2026-0001','RAMIREZ','LAUDER DALE','','SALIDO','Female','Married','1940-10-02',85,'MANILA','ORION BATAAN','12111211',22,'Without Pension','100000.00','Active','EDGAR RAMIREZ','111455','BALANGA CITY BATAAN','COLLEGE','NURSE','0000-00-00',6,'2026-03-16 10:48:58',NULL),(74,'SC-2026-0002','DASDSSDSADA','ASDASDAS','Sr.','SADAD','Female','Married','1970-10-10',55,'SADAD','DSADA','1',27,'Without Pension','0.00','Deceased','SADAS','1','ASDA','SADA','DAS','2024-10-10',NULL,'2026-03-16 10:48:58',NULL),(75,'SC-2026-0003','JOJO','XZC','Sr.','ZCXCZ','Male','Married','1946-10-10',79,'SADAD','SADA','1',24,'Without Pension','0.00','Deceased','ASDA','1','SAD','SADASDSA','DASDSA','2025-10-10',NULL,'2026-03-16 10:48:58',NULL),(76,'SC-2026-0004','KALY','KLAY','','EEEE','Female','Married','1970-10-10',55,'sadsda','sadadsas','1',25,'Without Pension','0.00','Active','asad','1','asda','asda','asd','0000-00-00',NULL,'2026-03-16 10:48:58',NULL),(77,'SC-2026-0005','HIPOLITO ','ADSON','Jr.','GITNA','Male','Married','1946-10-10',79,'ORION','ORION BATAAN','12121',11,'With Pension','101000.00','Active','DSADADA','1','SADA','COLLEGE','DOCTOR','0000-00-00',NULL,'2026-03-16 10:48:58',NULL),(78,'SC-2026-0006','RAMONT','ANG','','SDAA','Male','Separated','1940-12-12',85,'sdas','sdada','1',33,'With Pension','1.00','Active','sda','1','szsa','sada','asd','0000-00-00',1,'2026-03-16 10:48:58',NULL),(79,'SC-2026-0007','JAKE','ASDADASD','','DASAD','Male','Married','1940-10-10',85,'sadd','sdadsa','1',26,'Without Pension','0.00','Deceased','sdadsa','1','dassad','sada','dasd','2026-03-16',7,'2026-03-16 10:48:58',NULL),(80,'SC-2026-0008','JOLEN','ADSSADASZ','','SADADSA','Female','Married','1945-10-10',80,'dsaawd','dsadas','1',24,'Without Pension','0.00','Active','sada','1','sdasda','sadad','sada','0000-00-00',7,'2026-03-16 10:48:58',NULL),(81,'SC-2026-0009','RUBY','ADASD','','DSADA','Female','Married','1945-10-10',80,'asdsad','dsada','1',25,'Without Pension','0.00','Active','asda','1','asda','daasd','ssdsaa','0000-00-00',1,'2026-03-16 10:48:58',NULL),(82,'SC-2026-0010','ROSEAAN','ASDA','','SADA','Female','Married','1940-12-12',85,'dsadasc','dsadad','1',25,'Without Pension','0.00','Active','sadasd','1','sada','dsadas','dasda','0000-00-00',1,'2026-03-16 10:53:57',NULL),(83,'SC-2026-0011','CHANG','CHONG','','SADADAS','Female','Widowed','1978-10-10',47,'asdasd','sdadsa','1',26,'Without Pension','0.00','Active','asd','1','sadad','sadadas','dsa','0000-00-00',1,'2026-03-16 11:27:02',NULL),(84,'SC-2026-0012','JUSTINE','SADAD','Sr.','DSADSADSA','Female','Married','1975-10-10',50,'sadsad','dsadas','1',26,'Without Pension','0.00','Active','sadsa','1','sadad','dsadsad','dasda','0000-00-00',1,'2026-03-16 12:01:44',NULL),(85,'SC-2026-0011','LEBRON ','JAMES','','SADAD','Male','Married','1945-10-10',80,'sada','sadas','1',25,'Without Pension','0.00','Active','sada','1','asda','dsadsad','sadda','0000-00-00',1,'2026-03-16 13:18:16',NULL),(86,'SC-2026-0011','LALA','AWSDA','','ASDD','Female','Married','1945-10-10',80,'sda','sdasa','1',26,'Without Pension','0.00','Active','sad','1','asda','sada','asda','0000-00-00',1,'2026-03-16 13:20:02',NULL),(87,'SC-2026-0012','POGI','ASD','Jr.','SAD','Male','Single','2026-03-04',0,'asd','asd','123',24,'With Pension','13123123.00','Active','asd','asd','asd','asd','asd','0000-00-00',1,'2026-03-16 13:23:03',NULL),(88,'SC-2026-0012','TINA','ASDAD','','SADA','Female','Widowed','1940-12-12',85,'ada','asdad','1',25,'Without Pension','0.00','Active','asda','1','asdad','adsad','adsa','0000-00-00',1,'2026-03-16 13:24:41',NULL),(89,'SC-2026-0013','XIAN','ASDA','Jr.','ASDAD','Female','Married','1945-12-12',80,'sada','adsa','sda',25,'Without Pension','0.00','Deceased','adssa','1','asdsad','asda','dsada','2026-10-15',1,'2026-03-16 13:25:23',NULL),(90,'SC-2026-0014','RONELS','EWAN','','AWEA','Male','Married','1970-10-10',55,'sdads','sada','1',22,'Without Pension','0.00','Active','sadsa','1','sadad','sadsad','sada','0000-00-00',1,'2026-03-16 13:26:10',NULL),(91,'SC-2026-0015','KIKI','SADA','','SADA','Female','Married','1970-10-10',55,'asadsad','dsadas','1',23,'Without Pension','0.00','Deceased','sada','1','asdsad','sdads','dasdas','2025-10-10',7,'2026-03-16 14:36:46',NULL),(92,'SC-2026-0016','sadad','sadad','Sr.','sadas','Male','Single','1940-10-10',85,'sdadad','sdadasd','1',18,'With Pension','1.00','Active','sdada','1','asda','asda','dsa',NULL,NULL,'2026-03-17 15:00:10',NULL),(93,'SC-2026-0017','MAGSINO','DOLORES','','MACAPINLAC','Female','Widowed','1946-05-10',79,'PAMPANGA','ORION BATAAN','1',30,'Without Pension','0.00','Active','DALE MAGSINO','1','LIMAY','COLLEGE','NURSE',NULL,NULL,'2026-03-17 15:03:41',NULL),(94,'SC-2026-0018','SILVA','SAHRA','','SANTIAGO','Female','Single','1946-10-10',79,'LIMAY','ORION BATAAN','123456',0,'With Pension','0.00','Active','SINO NGA BA','1','LIMAY','COLLEGE','NURSE',NULL,NULL,'2026-03-17 15:15:46',NULL),(95,'SC-2026-0019','JAKE ','ALBERT','','ASDADADS','Male','Widowed','1946-10-10',79,'SDASAD','ADSSADA','1',23,'With Pension','111.00','Active','ASDA','1','DASDAD','SDSADA','DADADAD',NULL,NULL,'2026-03-17 15:21:39',NULL),(96,'SC-2026-0020','ADSON','ADSON','','ASDADA','Male','Married','1945-12-12',80,'SADAD','SDADAD','1',0,'Without Pension','0.00','Active','DSADA','1','SADA','SDADSA','DSAD',NULL,NULL,'2026-03-17 15:25:37',NULL),(97,'SC-2026-0021','jajajajaja','asdssadada','','sadada','Male','Married','1945-10-10',80,'asdsada','sdad','1',0,'With Pension','111.00','Active','sada','1','dsadad','asdas','dsad',NULL,NULL,'2026-03-17 15:50:27',NULL),(98,'SC-2026-0022','MICHAEL','SOLOMON','','SADASD','Male','Widowed','1945-12-12',80,'SADAD','SDAAD','1',0,'With Pension','1111.00','Active','ASDA','1','ASDA','SADA','DDSA',NULL,NULL,'2026-03-17 15:52:40',NULL),(99,'SC-2026-0023','CRIS','CRIS','','asdsadas','Male','Married','1970-10-10',55,'adads','dasda','`',0,'With Pension','111.00','Active','adsasd','1','asdas','sada','dada',NULL,NULL,'2026-03-17 16:49:23',NULL),(100,'SC-2026-0024','DANTES','DING-DONG','','KURIMAW','Male','Married','1940-10-10',85,'MANILA','ORION BATAAN','09213644279',18,'Without Pension','0.00','Active','JULIAN PONTES','09442123152','LIMAY','COLLEGE','ARTIST','0000-00-00',NULL,'2026-03-17 16:53:46',NULL),(101,'SC-2026-0025','BALBUENA','ALDRIN','','CRUZ','Male','Married','1948-11-04',77,'MANILA','ORION BATAAN','12115445515',30,'With Pension','10000.00','Active','JOMAG POGI','122324','LIMAY','COLLEGE','POLICE',NULL,NULL,'2026-03-17 21:31:28',NULL),(102,'SC-2026-0026','YAYAY','YAYAYAYA','II','WALA','Female','Married','1946-10-10',79,'SDADSA','SADADSA','1',16,'Without Pension','0.00','Active','SDADSA','1','ASDA','SADSAD','SADADA',NULL,NULL,'2026-03-17 21:39:56',NULL),(103,'SC-2026-0027','SASA','SALMON','','ASDADADSA','Female','Married','1940-10-10',85,'ASDASDSA','SADADA','1',18,'Without Pension','0.00','Active','sdadaad','1','asdsadas','dsadsada','da',NULL,NULL,'2026-03-17 22:43:32',NULL),(104,'SC-2026-0028','sadasdasdadasdadasdas','kiki','','asasda','Female','Married','1940-10-10',85,'sdasda','sada','1',21,'With Pension','1111.00','Active','sdad','1','asdasda','sdasd','sadas',NULL,NULL,'2026-03-17 22:48:17',NULL),(105,'SC-2026-0029','CRUZ','GENESIS','','MAMAMA','Male','Separated','1940-10-10',85,'MANILA','SADASDASD','1',0,'With Pension','111.00','Active','zczczxc','1','cxzcxzcxzcz','zczcz','zcxzc',NULL,NULL,'2026-03-18 09:00:07','flashbackstv@gmail.com'),(106,'SC-2026-0029','SDSADADA','ELMER','','SADSADASD','Female','Married','1940-12-01',85,'sadada','sadasadsad','sdadada',21,'With Pension','111.00','Active','asdsad','1','sdsadasd','sdadas','dasda','0000-00-00',1,'2026-03-18 09:12:45','jojo@gmail.com'),(107,'SC-2026-0030','sadsadsa','dsadsadas','','sadsadsa','Male','Married','1945-12-12',80,'sadwasd','sdada','sadadsa',0,'With Pension','1.00','Active','asdsad','1','sdsad','sadad','dasda',NULL,NULL,'2026-03-18 09:38:08','sad@gmail.com'),(108,'SC-2026-0031','SOLEM','SOLEM','','SADADA','Male','Married','1940-12-12',85,'ASDASD','SADASD','ASD',23,'With Pension','1.00','Active','ASDSA','D1','ASDAD','SADAD','ASDA',NULL,NULL,'2026-03-18 09:46:56','jomags1001@gmail.com'),(109,'SC-2026-0032','GLORIA','EMMANUEL','','NATIVIDAD','Male','Married','1942-10-10',83,'ORION','ORION BATAAN','1213',24,'Without Pension','0.00','Active','ALING NENE','313423','LIMAY','COLLEGE','POLICE','0000-00-00',NULL,'2026-03-18 10:21:05','jojokulit11@gmail.com'),(110,'SC-2026-0033','dsadas','dsadasdsad','','asdsadsada','Male','Married','1940-12-10',85,'asdasdasd','sadsadadad','sadadasda',0,'With Pension','0.00','Active','sadsada','111','sdadsadas','sadasd','dasda',NULL,NULL,'2026-03-18 10:34:30','engersonlinegame134@gmail.com');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','staff','barangay') NOT NULL,
  `barangay_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `users` */

insert  into `users`(`id`,`name`,`username`,`password`,`role`,`barangay_id`,`created_at`) values (1,'System Administrator','admin','0192023a7bbd73250516f069df18b500','admin',NULL,'2026-03-11 17:02:02'),(5,'ENGERS MAGSINO','engers','c4ca4238a0b923820dcc509a6f75849b','barangay',27,'2026-03-16 08:49:47'),(6,'jojo','jojo','c4ca4238a0b923820dcc509a6f75849b','barangay',25,'2026-03-16 09:31:55'),(7,'dale','dale','c4ca4238a0b923820dcc509a6f75849b','staff',0,'2026-03-16 09:59:05');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
