/*
SQLyog Enterprise - MySQL GUI v8.18 
MySQL - 5.5.5-10.1.31-MariaDB : Database - scims_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`scims_db` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `scims_db`;

/*Table structure for table `barangay` */

DROP TABLE IF EXISTS `barangay`;

CREATE TABLE `barangay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `contact_person_number` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

/*Data for the table `barangay` */

insert  into `barangay`(`id`,`name`,`contact`,`email`,`contact_person`,`contact_person_number`) values (11,'Arellano (Poblacion)','1','trial@gmail.com','SEC.','1'),(12,'Bagumbayan (Poblacion)','1','trial@gmail.com','SEC.','1'),(13,'Balagtas (Poblacion)','1','trial@gmail.com','SEC.','1'),(14,'Balut (Poblacion)','1','trial@gmail.com','SEC.','1'),(15,'Bantan','1','trial@gmail.com','SEC.','1'),(16,'Bilolo','1','trial@gmail.com','SEC.','1'),(17,'Calungusan','1','trial@gmail.com','SEC.','1'),(18,'Camachile','1','trial@gmail.com','SEC.','1'),(19,'Daang Bago (Poblacion)','1','trial@gmail.com','SEC.','1'),(20,'Daang Bilolo (Poblacion)','1','trial@gmail.com','SEC.','1'),(21,'Daang Pare','1','trial@gmail.com','SEC.','1'),(22,'General Lim (Kapunitan)','1','trial@gmail.com','SEC.','1'),(23,'Kapunitan','1','trial@gmail.com','SEC.','1'),(24,'Lati (Poblacion)','1','trial@gmail.com','SEC.','1'),(25,'Lusungan (Poblacion)','1','trial@gmail.com','SEC.','1'),(26,'Puting Buhangin','1','trial@gmail.com','SEC.','1'),(27,'Sabatan','1','trial@gmail.com','SEC.','1'),(28,'San Vicente (Poblacion)','1','trial@gmail.com','SEC.','1'),(29,'Santa Elena','1','trial@gmail.com','SEC.','1'),(30,'Santo Domingo','1','trial@gmail.com','SEC.','1'),(31,'Villa Angeles (Poblacion)','1','trial@gmail.com','SEC.','1'),(32,'Wakas (Poblacion)','1','trial@gmail.com','SEC.','1'),(33,'Wawa (Poblacion) ','1','trial@gmail.com','SEC.','1');

/*Table structure for table `family_composition` */

DROP TABLE IF EXISTS `family_composition`;

CREATE TABLE `family_composition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `senior_id` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `relationship` varchar(50) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `civil_status` varchar(50) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `income` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `senior_id` (`senior_id`),
  CONSTRAINT `family_composition_ibfk_1` FOREIGN KEY (`senior_id`) REFERENCES `senior_citizens` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

/*Data for the table `family_composition` */

insert  into `family_composition`(`id`,`senior_id`,`name`,`relationship`,`age`,`civil_status`,`occupation`,`income`) values (26,55,'THYLAINE','ANAK',3,'Single','N/A','0.00'),(27,55,'AAA','AA',1,'Single','AA','1.00'),(28,60,'THYLAINE MCKENZIE MAGSINO','ANAK',3,'Single','N/A','0.00'),(29,55,'CHONG KWAYLA','TITA',47,'Widowed','TAMBIKE','5000.00'),(30,61,'MARIA OSAWA','WIFE',60,'Married','POLICE','10000.00'),(31,61,'JULIA MONTER','SISTER',20,'Single','N/A','0.00'),(32,64,'JOJO MAGSINO','FATHER',90,'Married','DOCTOR','100000.00'),(33,65,'THYLAINE','ANAK',3,'Single','N/A','0.00'),(34,65,'MARIA OSAWA','ANAK',1,'Single','N/A','0.00'),(35,67,'sada','asda',1,'Single','N/A','0.00'),(36,68,'asdad','aasd',1,'Married','asdad','0.00');

/*Table structure for table `senior_citizens` */

DROP TABLE IF EXISTS `senior_citizens`;

CREATE TABLE `senior_citizens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sc_id` varchar(50) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `extension` varchar(10) DEFAULT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `civil_status` varchar(50) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `birth_place` varchar(150) DEFAULT NULL,
  `address` text,
  `contact_info` varchar(100) DEFAULT NULL,
  `barangay_id` int(11) DEFAULT NULL,
  `pension_status` varchar(20) DEFAULT NULL,
  `monthly_pension` decimal(10,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `emergency_person` varchar(150) DEFAULT NULL,
  `emergency_number` varchar(50) DEFAULT NULL,
  `emergency_address` text,
  `education` varchar(100) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `date_of_death` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=latin1;

/*Data for the table `senior_citizens` */

insert  into `senior_citizens`(`id`,`sc_id`,`last_name`,`first_name`,`extension`,`middle_name`,`gender`,`civil_status`,`birthdate`,`age`,`birth_place`,`address`,`contact_info`,`barangay_id`,`pension_status`,`monthly_pension`,`status`,`emergency_person`,`emergency_number`,`emergency_address`,`education`,`occupation`,`date_of_death`) values (55,'1010','MAGSINO','JOJO','III','MACAPINLAC','Male','Married','1945-10-01',80,'PAMPANGA','ORION BATAAN','1234567',14,'With Pension','10000.00','Active','DALE MAGSINO','124','BALANGA','COLLEGE','POLICE','0000-00-00'),(56,'11','ksadasd','sada','Jr.','sa','Female','Married','1945-10-10',80,'sdaza','sdada','1',13,'Without Pension','1.00','Active','sada','1','szda','szx','zcx','0000-00-00'),(57,'1ssadadsa','asdasadad','dasdasadad','','dasda','Female','Married','1945-10-10',80,'sadds','dasda','1',18,'Without Pension','0.00','Active','ssada','1','dsada','asdad','sada','0000-00-00'),(58,'1111','sadasc','zczczc',NULL,'zxczcz','Male','Married','1994-11-22',31,'sdcz','sdad','1',15,'Without Pension','0.00','Active','zxc ','1','xzc','czxcz','zxc','0000-00-00'),(59,'1','as','jojo',NULL,'sa','Male','Single','1945-12-12',80,'aszc','zxc','1',14,'Without Pension','0.00','Deceased','sda','1','sczx ','college','casz','2000-10-10'),(60,'1','MAGSINO','LAUDER DALE',NULL,'RAMIREZ','Female','Married','1945-10-02',80,'BALANGA','ORION BATAAN','1',27,'With Pension','50000.00','Active','ENGERS MAGSINO','19199191','ORION BATAAN','COLLEGE','DOCTOR','0000-00-00'),(61,'666','DELA CRUZ','JUAN','Jr.','TAMAD','Male','Widowed','1945-10-10',80,'PAMPANGA','ORION BATAAN','090909090',23,'With Pension','111111.00','Deceased','PETER NORTH ','12232','ORION BATAAN','COLLEGE','POLICE','2025-10-10'),(62,'111','sdad','asda',NULL,'sadad','Female','Married','1945-12-12',80,'sada','sdada','1',15,'With Pension','1.00','Active','szcx','1','sadz','xzcz','czczc','0000-00-00'),(63,'1','sad','sda',NULL,'sad','Male','Married','2000-12-12',25,'sadaz','dsadasdsa','1',12,'Without Pension','1111.00','Active','zxzcz','czx','czx','zxzxc','czx','0000-00-00'),(64,'042323','MAGSINO','THYLAINE MCKENZIE','IV','RAMIREZ','Female','Single','1945-04-23',80,'BALANGA, BATAAN','ORION BATAAN','09213644279',19,'With Pension','0.00','Active','LAUDER DALE MAGSINO','09212365456','ORION BATAAN','COLLEGE','DOCTOR','0000-00-00'),(65,'999999','RAMO','JAY','Jr.','SEA','Male','Single','1945-10-10',80,'PAMPANGA','ORION BATAAN','1234567',14,'Without Pension','0.00','Deceased','DALE MAGSINO','19199191','BALANGA','COLLEGE','POLICE','2025-10-10'),(66,'SC-2026-10000','sada','asda','Jr.','sadsada','Female','Married','1945-10-10',80,'sadasd','ORION BATAAN','1234567',13,'Without Pension','0.00','Active','sad','1','asda','COLLEGE','POLICE','0000-00-00'),(67,'SC-2026-0001','sasad','adsasda','Jr.','asdada','Female','Single','1978-10-10',47,'asdada','ORION BATAAN','09213644279',26,'With Pension','0.00','Active','sadsad','1','sadada','sadsada','sad','0000-00-00'),(68,'SC-2026-0002','asdadad','asdadada','Sr.','asdada','Female','Married','1940-10-10',85,'asdasdaas','ORION BATAAN','1234567',25,'With Pension','111111.00','Active','PETER NORTH ','1','dsadaw','sdsadsa','POLICE','0000-00-00'),(69,'SC-2026-0003','asda','sada','','sadad','Male','Married','1970-10-10',55,'sadasd','ORION BATAAN','1',27,'Without Pension','0.00','Active','sadsa','1','sadsa','sada','sad','0000-00-00'),(70,'SC-2026-0004','dsfsf','JOJO','Jr.','sa','Female','Married','1940-10-10',85,'sdasda','sadas','1234567',25,'With Pension','0.00','Active','sad','1','sad','sadsa','sad','0000-00-00'),(71,'SC-2026-0005','sadada','sadsa','','sadsa','Female','Married','1940-12-11',85,'sadasd','sadsad','1234567',26,'With Pension','0.00','Active','asdas','1q','sadsad','sadsa','POLICE','0000-00-00');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
