/*
SQLyog Enterprise - MySQL GUI v8.18 
MySQL - 5.5.5-10.1.31-MariaDB : Database - scims_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`scims_db` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `scims_db`;

/*Table structure for table `barangay` */

DROP TABLE IF EXISTS `barangay`;

CREATE TABLE `barangay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `contact_person_number` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

/*Data for the table `barangay` */

insert  into `barangay`(`id`,`name`,`contact`,`email`,`contact_person`,`contact_person_number`) values (11,'Arellano (Poblacion)','2','trial@gmail.com','SEC.','1'),(12,'Bagumbayan (Poblacion)','1','trial@gmail.com','SEC.','1'),(13,'Balagtas (Poblacion)','1','trial@gmail.com','SEC.','1'),(14,'Balut (Poblacion)','1','trial@gmail.com','SEC.','1'),(15,'Bantan','1','trial@gmail.com','SEC.','1'),(16,'Bilolo','1','trial@gmail.com','SEC.','1'),(17,'Calungusan','1','trial@gmail.com','SEC.','1'),(18,'Camachile','1','trial@gmail.com','SEC.','1'),(19,'Daang Bago (Poblacion)','1','trial@gmail.com','SEC.','1'),(20,'Daang Bilolo (Poblacion)','1','trial@gmail.com','SEC.','1'),(21,'Daang Pare','1','trial@gmail.com','SEC.','1'),(22,'General Lim (Kapunitan)','1','trial@gmail.com','SEC.','1'),(23,'Kapunitan','1','trial@gmail.com','SEC.','1'),(24,'Lati (Poblacion)','1','trial@gmail.com','SEC.','1'),(25,'Lusungan (Poblacion)','1','trial@gmail.com','SEC.','1'),(26,'Puting Buhangin','1','trial@gmail.com','SEC.','1'),(27,'Sabatan','1','trial@gmail.com','SEC.','1'),(28,'San Vicente (Poblacion)','1','trial@gmail.com','SEC.','1'),(29,'Santa Elena','1','trial@gmail.com','SEC.','1'),(30,'Santo Domingo','1','trial@gmail.com','SEC.','1'),(31,'Villa Angeles (Poblacion)','1','trial@gmail.com','SEC.','1'),(32,'Wakas (Poblacion)','1','trial@gmail.com','SEC.','1'),(33,'Wawa (Poblacion) ','1','trial@gmail.com','SEC.','1');

/*Table structure for table `family_composition` */

DROP TABLE IF EXISTS `family_composition`;

CREATE TABLE `family_composition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `senior_id` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `relationship` varchar(50) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `civil_status` varchar(50) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `income` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `senior_id` (`senior_id`),
  CONSTRAINT `family_composition_ibfk_1` FOREIGN KEY (`senior_id`) REFERENCES `senior_citizens` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

/*Data for the table `family_composition` */

insert  into `family_composition`(`id`,`senior_id`,`name`,`relationship`,`age`,`civil_status`,`occupation`,`income`) values (37,73,'THYLAINE MAGSINO','MOTHERs',3,'Single','N/A','0.00'),(38,75,'SAD','ADAS',1,'Single','N/A','0.00'),(39,73,'sdasdas','sda',11,'Single','','0.00'),(40,77,'AAAA','AAA',1,'Single','N/A','0.00'),(41,79,'sadsa','dasd',1,'Single','n/a','0.00'),(42,85,'dasdas','asd',1,'Single','','0.00');

/*Table structure for table `senior_citizens` */

DROP TABLE IF EXISTS `senior_citizens`;

CREATE TABLE `senior_citizens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sc_id` varchar(50) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `extension` varchar(10) DEFAULT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `civil_status` varchar(50) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `birth_place` varchar(150) DEFAULT NULL,
  `address` text,
  `contact_info` varchar(100) DEFAULT NULL,
  `barangay_id` int(11) DEFAULT NULL,
  `pension_status` varchar(20) DEFAULT NULL,
  `monthly_pension` decimal(10,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `emergency_person` varchar(150) DEFAULT NULL,
  `emergency_number` varchar(50) DEFAULT NULL,
  `emergency_address` text,
  `education` varchar(100) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `date_of_death` date DEFAULT NULL,
  `encoded_by` int(11) DEFAULT NULL,
  `date_encoded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=latin1;

/*Data for the table `senior_citizens` */

insert  into `senior_citizens`(`id`,`sc_id`,`last_name`,`first_name`,`extension`,`middle_name`,`gender`,`civil_status`,`birthdate`,`age`,`birth_place`,`address`,`contact_info`,`barangay_id`,`pension_status`,`monthly_pension`,`status`,`emergency_person`,`emergency_number`,`emergency_address`,`education`,`occupation`,`date_of_death`,`encoded_by`,`date_encoded`) values (72,'SC-2026-0001','MAGSINO','ENGERS','','MACAPINLAC','Male','Married','1970-10-01',55,'PAMPANGA','ORION BATAAN','09213644279',27,'Without Pension','0.00','Active','LAUDER DALE MAGSINO','12331233','BALANGA BATAAN','COLLEGE','POLICE','0000-00-00',NULL,'2026-03-16 10:48:58'),(73,'SC-2026-0001','RAMIREZ','LAUDER DALE','','SALIDO','Female','Married','1940-10-02',85,'MANILA','ORION BATAAN','12111211',22,'Without Pension','100000.00','Active','EDGAR RAMIREZ','111455','BALANGA CITY BATAAN','COLLEGE','NURSE','0000-00-00',6,'2026-03-16 10:48:58'),(74,'SC-2026-0002','DASDSSDSADA','ASDASDAS','Sr.','SADAD','Female','Married','1970-10-10',55,'SADAD','DSADA','1',27,'Without Pension','0.00','Deceased','SADAS','1','ASDA','SADA','DAS','2024-10-10',NULL,'2026-03-16 10:48:58'),(75,'SC-2026-0003','JOJO','XZC','Sr.','ZCXCZ','Male','Married','1946-10-10',79,'SADAD','SADA','1',24,'Without Pension','0.00','Deceased','ASDA','1','SAD','SADASDSA','DASDSA','2025-10-10',NULL,'2026-03-16 10:48:58'),(76,'SC-2026-0004','KALY','KLAY','','EEEE','Female','Married','1970-10-10',55,'sadsda','sadadsas','1',25,'Without Pension','0.00','Active','asad','1','asda','asda','asd','0000-00-00',NULL,'2026-03-16 10:48:58'),(77,'SC-2026-0005','HIPOLITO ','ADSON','Jr.','GITNA','Male','Married','1946-10-10',79,'ORION','ORION BATAAN','12121',11,'With Pension','101000.00','Active','DSADADA','1','SADA','COLLEGE','DOCTOR','0000-00-00',NULL,'2026-03-16 10:48:58'),(78,'SC-2026-0006','RAMONT','ANG','','SDAA','Male','Separated','1940-12-12',85,'sdas','sdada','1',33,'With Pension','1.00','Active','sda','1','szsa','sada','asd','0000-00-00',1,'2026-03-16 10:48:58'),(79,'SC-2026-0007','JAKE','ASDADASD','','DASAD','Male','Married','1940-10-10',85,'sadd','sdadsa','1',26,'Without Pension','0.00','Deceased','sdadsa','1','dassad','sada','dasd','2026-03-16',7,'2026-03-16 10:48:58'),(80,'SC-2026-0008','JOLEN','ADSSADASZ','','SADADSA','Female','Married','1945-10-10',80,'dsaawd','dsadas','1',24,'Without Pension','0.00','Active','sada','1','sdasda','sadad','sada','0000-00-00',7,'2026-03-16 10:48:58'),(81,'SC-2026-0009','RUBY','ADASD','','DSADA','Female','Married','1945-10-10',80,'asdsad','dsada','1',25,'Without Pension','0.00','Active','asda','1','asda','daasd','ssdsaa','0000-00-00',1,'2026-03-16 10:48:58'),(82,'SC-2026-0010','ROSEAAN','ASDA','','SADA','Female','Married','1940-12-12',85,'dsadasc','dsadad','1',25,'Without Pension','0.00','Active','sadasd','1','sada','dsadas','dasda','0000-00-00',1,'2026-03-16 10:53:57'),(83,'SC-2026-0011','CHANG','CHONG','','SADADAS','Female','Widowed','1978-10-10',47,'asdasd','sdadsa','1',26,'Without Pension','0.00','Active','asd','1','sadad','sadadas','dsa','0000-00-00',1,'2026-03-16 11:27:02'),(84,'SC-2026-0012','JUSTINE','SADAD','Sr.','DSADSADSA','Female','Married','1975-10-10',50,'sadsad','dsadas','1',26,'Without Pension','0.00','Active','sadsa','1','sadad','dsadsad','dasda','0000-00-00',1,'2026-03-16 12:01:44'),(85,'SC-2026-0011','LEBRON ','JAMES','','SADAD','Male','Married','1945-10-10',80,'sada','sadas','1',25,'Without Pension','0.00','Active','sada','1','asda','dsadsad','sadda','0000-00-00',1,'2026-03-16 13:18:16'),(86,'SC-2026-0011','LALA','AWSDA','','ASDD','Female','Married','1945-10-10',80,'sda','sdasa','1',26,'Without Pension','0.00','Active','sad','1','asda','sada','asda','0000-00-00',1,'2026-03-16 13:20:02'),(87,'SC-2026-0012','POGI','ASD','Jr.','SAD','Male','Single','2026-03-04',0,'asd','asd','123',24,'With Pension','13123123.00','Active','asd','asd','asd','asd','asd','0000-00-00',1,'2026-03-16 13:23:03'),(88,'SC-2026-0012','TINA','ASDAD','','SADA','Female','Widowed','1940-12-12',85,'ada','asdad','1',25,'Without Pension','0.00','Active','asda','1','asdad','adsad','adsa','0000-00-00',1,'2026-03-16 13:24:41'),(89,'SC-2026-0013','XIAN','ASDA','Jr.','ASDAD','Female','Married','1945-12-12',80,'sada','adsa','sda',25,'Without Pension','0.00','Deceased','adssa','1','asdsad','asda','dsada','2026-10-15',1,'2026-03-16 13:25:23'),(90,'SC-2026-0014','RONELS','EWAN','','AWEA','Male','Married','1970-10-10',55,'sdads','sada','1',22,'Without Pension','0.00','Active','sadsa','1','sadad','sadsad','sada','0000-00-00',1,'2026-03-16 13:26:10'),(91,'SC-2026-0015','KIKI','SADA','','SADA','Female','Married','1970-10-10',55,'asadsad','dsadas','1',23,'Without Pension','0.00','Deceased','sada','1','asdsad','sdads','dasdas','2025-10-10',7,'2026-03-16 14:36:46');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','staff','barangay') NOT NULL,
  `barangay_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `users` */

insert  into `users`(`id`,`name`,`username`,`password`,`role`,`barangay_id`,`created_at`) values (1,'System Administrator','admin','0192023a7bbd73250516f069df18b500','admin',NULL,'2026-03-11 17:02:02'),(5,'ENGERS MAGSINO','engers','c4ca4238a0b923820dcc509a6f75849b','barangay',27,'2026-03-16 08:49:47'),(6,'jojo','jojo','c4ca4238a0b923820dcc509a6f75849b','barangay',25,'2026-03-16 09:31:55'),(7,'dale','dale','c4ca4238a0b923820dcc509a6f75849b','staff',0,'2026-03-16 09:59:05');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
