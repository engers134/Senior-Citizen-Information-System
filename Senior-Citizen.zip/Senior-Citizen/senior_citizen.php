    <?php
    include "session_check.php";
    include "config.php";
    ?>
    <?php
    /* AUTO GENERATE SENIOR CITIZEN ID */

    $year = date("Y");

    $query = $conn->query("SELECT sc_id FROM senior_citizens ORDER BY id DESC LIMIT 1");

    if($query->num_rows > 0){

    $row = $query->fetch_assoc();

    $lastID = $row['sc_id'];

    $number = substr($lastID, -4);

    $number++;

    $newID = "SC-$year-".str_pad($number,4,"0",STR_PAD_LEFT);

    }else{

    $newID = "SC-$year-0001";

    }
    ?>
    <!DOCTYPE html>
    <html>
    <head>
    <title>Senior Citizen Management</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
    .sidebar { min-height:100vh; }
    .nav-link:hover { background:#495057; }
    </style>

    </head>

    <body class="bg-light">

    <div class="container-fluid">
    <div class="row">

    <?php include "sidebar.php"; ?>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">

    <h2 class="mb-4">Senior Citizen Management</h2>

    <?php if(isset($_GET['updated'])): ?>

        <?php if($_GET['updated'] == 1): ?>
            <div class="alert alert-success">
                Record updated successfully!
            </div>
        <?php else: ?>
            <div class="alert alert-warning">
                No changes were made.
            </div>
        <?php endif; ?>

    <?php endif; ?>

        <?php if(isset($_GET['add'])): ?>

            <?php if($_GET['add'] == 1): ?>
                <div class="alert alert-success">
                    Record Added successfully!
                </div>
            <?php else: ?>
                <div class="alert alert-warning">
                    No changes were made.
                </div>
            <?php endif; ?>

        <?php endif; ?>

    <!-- SEARCH -->
    <div class="card shadow-sm mb-4">
    <div class="card-body">
    <form method="GET" class="row g-3">

    <div class="col-md-4">
    <input type="text" name="search" class="form-control"
    placeholder="Search by ID or Name"
    value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>">

    </div>

    <div class="col-md-4">

    <select name="filter_barangay" class="form-select"
    <?php if($_SESSION['role'] == 'barangay'){ echo "disabled"; } ?>>

    <?php

    /* IF USER IS BARANGAY */
    if($_SESSION['role'] == 'barangay'){

        $barangay_id = $_SESSION['barangay_id'];

        $brgy = $conn->query("SELECT * FROM barangay WHERE id='$barangay_id'");
        
        while($row = $brgy->fetch_assoc()){
            echo "<option value='".$row['id']."' selected>".$row['name']."</option>";
        }

    }

    /* ADMIN / STAFF */
    else{

        echo "<option value=''>All Barangays</option>";

        $brgy = $conn->query("SELECT * FROM barangay ORDER BY name ASC");

        while($row = $brgy->fetch_assoc()){

            $selected="";

            if(isset($_GET['filter_barangay']) && $_GET['filter_barangay']==$row['id']){
                $selected="selected";
            }

            echo "<option value='".$row['id']."' $selected>".$row['name']."</option>";
        }

    }

    ?>

    </select>

    </div>

    <div class="col-md-4">
    <button class="btn btn-primary">Search</button>
    <a href="senior_citizen.php" class="btn btn-secondary">Reset</a>
    </div>

    </form>
    </div>
    </div>

    <!-- ADD BUTTON -->
    <div class="d-flex justify-content-between mb-3">
    <h4>Senior Citizen Records</h4>

    </div>

    <?php if($_SESSION['role'] != 'barangay'){ ?>

    <button class="btn btn-success" id="addBtn">
    + Add Senior Citizen
    </button>

    <?php } ?>

    <!-- TABLE -->
    <div class="card shadow-sm">
    <div class="card-body table-responsive">

    <table class="table table-bordered table-hover">
    <thead class="table-dark">
    <tr>
    <th>ID</th>
    <th>Name</th>
    <th>Age</th>
    <th>Barangay</th>
    <th>Status</th>
    <th>Encoded By</th>
    <th>Actions</th>
    </tr>
    </thead>
    <tbody>

    <?php
    $where="WHERE 1";

    if(isset($_GET['search']) && $_GET['search']!=''){
        $search=$_GET['search'];
        $where.=" AND (
            sc_id LIKE '%$search%' OR
            last_name LIKE '%$search%' OR
            first_name LIKE '%$search%' OR
            middle_name LIKE '%$search%'
        )";
    }


    /* BARANGAY FILTER */
    if(isset($_GET['filter_barangay']) && $_GET['filter_barangay']!=''){
        $barangay_filter=$_GET['filter_barangay'];
        $where.=" AND barangay_id='$barangay_filter'";
    }

    /* BARANGAY USER RESTRICTION */
    if($_SESSION['role'] == 'barangay'){

    $barangay_id = $_SESSION['barangay_id'];

    $where .= " AND senior_citizens.barangay_id = '$barangay_id'";

    }

    /* QUERY */
    $query="
    SELECT 
senior_citizens.*,
senior_citizens.email AS email,
barangay.name AS barangay_name,
IFNULL(users.name,'Unknown User') AS encoder,
IFNULL(senior_citizens.date_encoded,'') AS date_encoded

    FROM senior_citizens
    LEFT JOIN barangay ON senior_citizens.barangay_id=barangay.id
    LEFT JOIN users ON senior_citizens.encoded_by = users.id

    $where
    ORDER BY last_name ASC
    ";

    $result=$conn->query($query);

    while($row=$result->fetch_assoc()){
    echo "<tr>";
    echo "<td>".$row['sc_id']."</td>";
    echo "<td>".$row['last_name'].", ".$row['first_name']." ".
    ($row['extension'] ? $row['extension']." " : "").
    $row['middle_name']."</td>";
    echo "<td>".$row['age']."</td>";
    echo "<td>".$row['barangay_name']."</td>";
    echo "<td>".$row['status']."</td>";
    echo "<td>".$row['encoder']."</td>";
    echo "<td>";
    ?>

<a href="#"
class="btn btn-sm btn-info viewBtn"
data-id="<?php echo $row['id']; ?>"
data-scid="<?php echo $row['sc_id']; ?>"
data-lname="<?php echo $row['last_name']; ?>"
data-fname="<?php echo $row['first_name']; ?>"
data-extension="<?php echo $row['extension']; ?>"
data-mname="<?php echo $row['middle_name']; ?>"
data-gender="<?php echo $row['gender']; ?>"
data-civil="<?php echo $row['civil_status']; ?>"
data-birthdate="<?php echo $row['birthdate']; ?>"
data-age="<?php echo $row['age']; ?>"
data-birthplace="<?php echo $row['birth_place']; ?>"
data-barangay="<?php echo $row['barangay_name']; ?>"
data-address="<?php echo $row['address']; ?>"
data-contact="<?php echo $row['contact_info']; ?>"
data-email="<?php echo htmlspecialchars(isset($row['email']) ? $row['email'] : ''); ?>"
data-pension="<?php echo $row['pension_status']; ?>"
data-monthly="<?php echo $row['monthly_pension']; ?>"
data-status="<?php echo $row['status']; ?>"
data-dod="<?php echo $row['date_of_death']; ?>"
data-encoder="<?php echo $row['encoder']; ?>"
data-date="<?php echo $row['date_encoded']; ?>"
data-emperson="<?php echo $row['emergency_person']; ?>"
data-emnumber="<?php echo $row['emergency_number']; ?>"
data-emaddress="<?php echo $row['emergency_address']; ?>"
data-education="<?php echo $row['education']; ?>"
data-occupation="<?php echo $row['occupation']; ?>">
View
</a>


    <?php if($_SESSION['role'] != 'barangay'){ ?>

                    <a href='#'
                    class='btn btn-sm btn-warning editBtn'
                    data-id="<?php echo $row['id']; ?>"
                    data-scid="<?php echo $row['sc_id']; ?>"
                    data-lname="<?php echo $row['last_name']; ?>"
                    data-fname="<?php echo $row['first_name']; ?>"
                    data-extension="<?php echo $row['extension']; ?>"
                    data-mname="<?php echo $row['middle_name']; ?>"
                    data-gender="<?php echo $row['gender']; ?>"
                    data-civil="<?php echo $row['civil_status']; ?>"
                    data-birthdate="<?php echo $row['birthdate']; ?>"
                    data-birthplace="<?php echo $row['birth_place']; ?>"
                    data-barangay="<?php echo $row['barangay_id']; ?>"
                    data-address="<?php echo $row['address']; ?>"
                    data-contact="<?php echo $row['contact_info']; ?>"
                    data-email="<?php echo $row['email']; ?>"
                    data-pension="<?php echo $row['pension_status']; ?>"
                    data-monthly="<?php echo $row['monthly_pension']; ?>"
                    data-status="<?php echo $row['status']; ?>"
                    data-dod="<?php echo $row['date_of_death']; ?>"
                    data-education="<?php echo $row['education']; ?>"
                    data-occupation="<?php echo $row['occupation']; ?>"
                    data-emperson="<?php echo $row['emergency_person']; ?>"
                    data-emnumber="<?php echo $row['emergency_number']; ?>"
                    data-emaddress="<?php echo $row['emergency_address']; ?>"
                    class="btn btn-sm btn-warning">
                    Edit
                    </a>

    <?php } ?>

    <?php
    echo "</td>";

    }
    ?>

    </tbody>
    </table>

    </div>
    </div>

    </main>
    </div>
    </div>

    <!-- MODAL -->
    <div class="modal fade" id="seniorModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
    <div class="modal-content">

    <div class="modal-header bg-success text-white">
    <h5 class="modal-title">Add Senior Citizen</h5>
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
    </div>

    <div class="modal-body">

    <form method="POST"
    action="add_senior.php"
    class="row g-3">

    <!--field-->
    <input type="hidden" name="record_id">

    <div class="col-md-4">
    <label class="form-label fw-bold">Senior Citizen ID</label><br>

    <span class="fw-bold px-3 py-2 border rounded">
    <?php echo $newID; ?>
    </span>

    <input type="hidden" name="sc_id" value="<?php echo $newID; ?>">
    </div>

    <div class="col-12"></div>

    <!-- Name Fields -->
    <div class="col-md-3">
    <label class="form-label">Last Name</label>
    <input type="text" name="lname" class="form-control" placeholder="Enter Last Name" required>
    </div>

    <div class="col-md-3">
    <label class="form-label">First Name</label>
    <input type="text" name="fname" class="form-control" placeholder="Enter First Name" required>
    </div>

    <div class="col-md-2">
    <label class="form-label">Extension Name</label>
    <select name="extension" class="form-select">
    <option value="">N/A</option>
    <option value="Jr.">Jr.</option>
    <option value="Sr.">Sr.</option>
    <option value="II">II</option>
    <option value="III">III</option>
    <option value="IV">IV</option>
    </select>
    </div>

    <div class="col-md-4">
    <label class="form-label">Middle Name</label>
    <input type="text" name="mname" class="form-control" placeholder="Enter Middle Name">
    </div>
    <div class="col-md-3">
    <label class="form-label">Gender</label>
    <select name="gender" class="form-select" required>
    <option value="" disabled selected hidden>Select Gender</option>
    <option value="Male" <?php if(isset($edit_data['gender']) && $edit_data['gender']=="Male") echo "selected"; ?>>Male</option>
    <option value="Female" <?php if(isset($edit_data['gender']) && $edit_data['gender']=="Female") echo "selected"; ?>>Female</option>
    </select>
    </div>


    <div class="col-md-3">
    <label class="form-label">Civil Status</label>
    <select name="civil_status" class="form-select" required>
    <option value="" disabled selected hidden>Select Civil Status</option>
    <option value="Single" <?php if(isset($edit_data['civil_status']) && $edit_data['civil_status']=="Single") echo "selected"; ?>>Single</option>
    <option value="Married" <?php if(isset($edit_data['civil_status']) && $edit_data['civil_status']=="Married") echo "selected"; ?>>Married</option>
    <option value="Widowed" <?php if(isset($edit_data['civil_status']) && $edit_data['civil_status']=="Widowed") echo "selected"; ?>>Widowed</option>
    <option value="Separated" <?php if(isset($edit_data['civil_status']) && $edit_data['civil_status']=="Separated") echo "selected"; ?>>Separated</option>
    </select>
    </div>

    <div class="col-md-3">
    <label class="form-label">Date of Birth</label>
    <input type="date" name="birthdate" class="form-control"
    value="<?php echo isset($edit_data['birthdate'])?$edit_data['birthdate']:''; ?>" required>
    </div>

    <div class="col-md-3">
    <label class="form-label">Place of Birth</label>
    <input type="text" name="birth_place" class="form-control"
    placeholder="Enter Place of Birth"
    value="<?php echo isset($edit_data['birth_place'])?$edit_data['birth_place']:''; ?>" required>
    </div>

    <div class="col-md-4">
    <label class="form-label">Barangay</label>
    <select name="barangay" class="form-select" required>
    <option value="" disabled selected hidden>Select Barangay</option>
    <?php
    $brgy = $conn->query("SELECT * FROM barangay ORDER BY name ASC");
    while($b = $brgy->fetch_assoc()){
        $selected = (isset($edit_data['barangay_id']) && $edit_data['barangay_id']==$b['id']) ? "selected" : "";
        echo "<option value='".$b['id']."' $selected>".$b['name']."</option>";
    }
    ?>
    </select>
    </div>

    <div class="col-md-8">
    <label class="form-label">Complete Address</label>
    <input type="text" name="address" class="form-control"
    placeholder="Enter Complete Address"
    value="<?php echo isset($edit_data['address'])?$edit_data['address']:''; ?>" required>
    </div>

    <div class="col-md-6">
    <label class="form-label">Contact Number</label>
    <input type="text" name="contact_info" class="form-control"
    placeholder="Enter contact number"
    value="<?php echo isset($edit_data['contact_info'])?$edit_data['contact_info']:''; ?>" required>
    </div>

     <div class="col-md-6">
<label class="form-label">Email Address</label>
<input type="email" name="email" class="form-control">
</div>

    <div class="col-md-3">
    <label class="form-label">Pension Status</label>
    <select name="pension" class="form-select" required>
    <option value="" disabled selected hidden>Select Pension Status</option>

    <option value="With Pension" <?php if(isset($edit_data['pension_status']) && $edit_data['pension_status']=="With Pension") echo "selected"; ?>>With Pension</option>
    <option value="Without Pension" <?php if(isset($edit_data['pension_status']) && $edit_data['pension_status']=="Without Pension") echo "selected"; ?>>Without Pension</option>
    </select>
    </div>

    <div class="col-md-3">
    <label class="form-label">Monthly Pension</label>
    <input type="number" name="monthly_pension" class="form-control"
    placeholder="Enter monthly pension"
    value="<?php echo isset($edit_data['monthly_pension'])?$edit_data['monthly_pension']:''; ?>">
    </div>

    <div class="col-md-3">
    <label class="form-label">Status</label>
    <select name="status" id="statusField" class="form-select" required>
    <option value="" disabled selected>Select Status</option>
    <option value="Active" <?php if(isset($edit_data['status']) && $edit_data['status']=="Active") echo "selected"; ?>>Active</option>
    <option value="Deceased" <?php if(isset($edit_data['status']) && $edit_data['status']=="Deceased") echo "selected"; ?>>Deceased</option>
    </select>


    </div>

    <div class="col-md-3" id="deathDateDiv" style="display:none;">
    <label class="form-label">Date of Death</label>
    <input type="date" name="date_of_death" id="date_of_death" class="form-control">
    </div>


    <!-- new add edu-->
    <hr>

    <h5>Educational and Work Information</h5>

    <div class="col-md-6">
    <label class="form-label">Educational Attainment</label>
    <input type="text" name="education" class="form-control"
    placeholder="Enter Educational Attainment"
    value="<?php echo isset($edit_data['education'])?$edit_data['education']:''; ?>" required>
    </div>

    <div class="col-md-6">
    <label class="form-label">Occupation</label>
    <input type="text" name="occupation" class="form-control"
    placeholder="Enter Occupation"
    value="<?php echo isset($edit_data['occupation'])?$edit_data['occupation']:''; ?>" required>
    </div>

    <hr>
    <h5>Family Composition</h5>

    <table class="table table-bordered" id="familyTable">

    <thead class="table-secondary">
    <tr>
    <th>Name</th>
    <th>Relationship</th>
    <th>Age</th>
    <th>Civil Status</th>
    <th>Occupation</th>
    <th>Income</th>
    <th>Action</th>
    </tr>
    </thead>

    <tbody id="familyBody">

    <tr>

    <td>
    <input type="hidden" name="family_id[]">
    <input type="text" name="family_name[]" class="form-control">
    </td>

    <td>
    <input type="text" name="relationship[]" class="form-control">
    </td>

    <td>
    <input type="number" name="family_age[]" class="form-control">
    </td>

    <td>
    <select name="family_civil[]" class="form-select">
    <option>Single</option>
    <option>Married</option>
    <option>Widowed</option>
    </select>
    </td>

    <td>
    <input type="text" name="family_occupation[]" class="form-control">
    </td>

    <td>
    <input type="number" name="family_income[]" class="form-control">
    </td>

    <td>
    <button type="button" class="btn btn-danger removeRow">X</button>
    </td>

    </tr>

    </tbody>
    </table>

    <button type="button" class="btn btn-primary" id="addFamilyRow">
    + Add Family Member
    </button>

    <hr>

    <h5>Emergency Contact Information</h5>

    <div class="col-md-4">
    <label class="form-label">Contact Person</label>
    <input type="text" name="em_person" class="form-control"
    placeholder="Enter Full Name"
    value="<?php echo isset($edit_data['emergency_person'])?$edit_data['emergency_person']:''; ?>" required>
    </div>

    <div class="col-md-4">
    <label class="form-label">Contact Number</label>
    <input type="text" name="em_number" class="form-control"
    placeholder="Enter Contact Number"
    value="<?php echo isset($edit_data['emergency_number'])?$edit_data['emergency_number']:''; ?>" required>
    </div>

    <div class="col-md-4">
    <label class="form-label">Address</label>
    <input type="text" name="em_address" class="form-control"
    placeholder="Enter Address"
    value="<?php echo isset($edit_data['emergency_address'])?$edit_data['emergency_address']:''; ?>" required>
    </div>

    <!-- SAVE CONFIRMATION MODAL -->
    <div class="modal fade" id="confirmSaveModal" tabindex="-1">
    <div class="modal-dialog">
    <div class="modal-content">

    <div class="modal-header bg-warning">
    <h5 class="modal-title">Confirm Save</h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
    </div>

    <div class="modal-body" id="confirmMessage">
    Are you sure you want to save this Senior Citizen record?
    </div>

    <div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
    No, Review Information
    </button>

    <button type="button" class="btn btn-success" id="confirmSaveBtn">
    Yes, Save Record
    </button>

    </div>

    </div>
    </div>
    </div>

    <div class="col-12 text-end">
    <button type="button" id="saveBtn" class="btn btn-success">
    Save
    </button>
    </div>

    </form>

    </div>
    </div>
    </div>
    </div>

    <!-- VIEW MODAL -->
    <div class="modal fade" id="viewModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
    <div class="modal-content">

    <div class="modal-header bg-primary text-white">
    <h5 class="modal-title">Senior Citizen Details</h5>
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
    </div>

   <div class="modal-body">

<div class="container-fluid">

<!-- IDENTIFICATION -->
<div class="card mb-3">
<div class="card-header bg-secondary text-white">
Identification Information
</div>

<div class="card-body row">

<div class="col-md-4">
<strong>Senior Citizen ID</strong><br>
<span id="v_scid"></span>
</div>

<div class="col-md-8">
<strong>Full Name</strong><br>
<span id="v_fullname"></span>
</div>

</div>
</div>


<!-- PERSONAL INFORMATION -->
<div class="card mb-3">
<div class="card-header bg-secondary text-white">
Personal Information
</div>

<div class="card-body row">

<div class="col-md-4">
<strong>Gender</strong><br>
<span id="v_gender"></span>
</div>

<div class="col-md-4">
<strong>Civil Status</strong><br>
<span id="v_civil"></span>
</div>

<div class="col-md-4">
<strong>Age</strong><br>
<span id="v_age"></span>
</div>

<div class="col-md-6">
<strong>Date of Birth</strong><br>
<span id="v_birthdate"></span>
</div>

<div class="col-md-6">
<strong>Place of Birth</strong><br>
<span id="v_birthplace"></span>
</div>

</div>
</div>


<!-- ADDRESS -->
<div class="card mb-3">
<div class="card-header bg-secondary text-white">
Address and Contact Information
</div>

<div class="card-body row">

<div class="col-md-6">
<strong>Barangay</strong><br>
<span id="v_barangay"></span>
</div>

<div class="col-md-6">
<strong>Status</strong><br>
<span id="v_status"></span>
</div>

<div class="col-md-6">
<strong>Date of Death:</strong><br>
<span id="v_dod"></span>
</div>

<div class="col-md-12">
<strong>Complete Address</strong><br>
<span id="v_address"></span>
</div>

<div class="col-md-6">
<strong>Contact Number</strong><br>
<span id="v_contact"></span>
</div>

<div class="col-md-6">
<strong>Email:</strong><br>
<span id="v_email"></span>

</div>
</div>


<!-- PENSION -->
<div class="card mb-3">
<div class="card-header bg-secondary text-white">
Pension Information
</div>

<div class="card-body row">

<div class="col-md-6">
<strong>Pension Status</strong><br>
<span id="v_pension"></span>
</div>

<div class="col-md-6">
<strong>Monthly Pension</strong><br>
<span id="v_monthly"></span>
</div>

</div>
</div>


<!-- EDUCATION -->
<div class="card mb-3">
<div class="card-header bg-secondary text-white">
Educational and Work Information
</div>

<div class="card-body row">

<div class="col-md-6">
<strong>Educational Attainment</strong><br>
<span id="v_education"></span>
</div>

<div class="col-md-6">
<strong>Occupation</strong><br>
<span id="v_occupation"></span>
</div>

</div>
</div>


<!-- SYSTEM INFO -->
<div class="card mb-3">
<div class="card-header bg-secondary text-white">
System Record Information
</div>

<div class="card-body row">

<div class="col-md-6">
<strong>Encoded By</strong><br>
<span id="v_encoder"></span>
</div>

<div class="col-md-6">
<strong>Date Encoded</strong><br>
<span id="v_date"></span>
</div>

</div>
</div>


<!-- FAMILY COMPOSITION -->
<div class="card mb-3">
<div class="card-header bg-secondary text-white">
Family Composition
</div>

<div class="card-body">

<div class="table-responsive">

<table class="table table-bordered">

<thead class="table-light">
<tr>
<th>Name</th>
<th>Relationship</th>
<th>Age</th>
<th>Civil Status</th>
<th>Occupation</th>
<th>Income</th>
</tr>
</thead>

<tbody id="familyTableBody"></tbody>

</table>

</div>

</div>
</div>


<!-- EMERGENCY CONTACT -->
<div class="card">
<div class="card-header bg-secondary text-white">
Emergency Contact Information
</div>

<div class="card-body row">

<div class="col-md-4">
<strong>Name</strong><br>
<span id="v_emperson"></span>
</div>

<div class="col-md-4">
<strong>Contact Number</strong><br>
<span id="v_emnumber"></span>
</div>

<div class="col-md-4">
<strong>Address</strong><br>
<span id="v_emaddress"></span>
</div>

</div>
</div>

</div>

</div>
    </div>
    </div>

    <?php if(isset($_GET['view'])){ ?>
    <script>
    var viewModal = new bootstrap.Modal(document.getElementById('viewModal'));
    viewModal.show();
                            </script>
                            <?php } ?>

                            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

        

            <script src="js/senior.js"></script>
        
        <script>
    setTimeout(function(){
        let alert = document.querySelector('.alert');
        if(alert){
            alert.style.display = 'none';
        }
    },3000);
    </script>                     
    </body>
    </html>




