<?php
include "send_email.php";
include "config.php";

/* GET DATA */
$id = $_GET['id'];

$data = $conn->query("SELECT * FROM pending_registrations WHERE id='$id'")->fetch_assoc();

/* GET BARANGAY ID FROM NAME */

$barangay_id = $data['barangay_id'];

/* AUTO GENERATE SC ID */
$year = date("Y");

$q = $conn->query("SELECT sc_id FROM senior_citizens ORDER BY id DESC LIMIT 1");

if($q->num_rows > 0){
$row = $q->fetch_assoc();
$num = substr($row['sc_id'], -4);
$num++;
$sc_id = "SC-$year-".str_pad($num,4,"0",STR_PAD_LEFT);
}else{
$sc_id = "SC-$year-0001";
}

/* CALCULATE AGE */
$birth = new DateTime($data['birthdate']);
$today = new DateTime();
$age = $today->diff($birth)->y;

/* INSERT INTO MAIN TABLE */
$conn->query("INSERT INTO senior_citizens
(sc_id,last_name,first_name,middle_name,extension,gender,civil_status,birthdate,age,birth_place,barangay_id,address,contact_info,email,pension_status,monthly_pension,status,education,occupation,emergency_person,emergency_number,emergency_address,date_encoded)

VALUES
('$sc_id','".$data['lname']."','".$data['fname']."','".$data['mname']."','".$data['extension']."','".$data['gender']."','".$data['civil_status']."','".$data['birthdate']."','$age','".$data['birth_place']."','$barangay_id','".$data['address']."','".$data['contact_info']."','".$data['email']."','".$data['pension_status']."','".$data['monthly_pension']."','Active','".$data['education']."','".$data['occupation']."','".$data['em_person']."','".$data['em_number']."','".$data['em_address']."',NOW())");

/* GET NEW SENIOR ID */

$senior_id = $conn->insert_id;

/* GET FAMILY MEMBERS FROM PENDING */

$fam = $conn->query("SELECT * FROM pending_family WHERE pending_id='$id'");


while($f = $fam->fetch_assoc()){

$conn->query("INSERT INTO family_composition
(senior_id,name,relationship,age,civil_status,occupation,income)

VALUES
('$senior_id','".$f['name']."','".$f['relationship']."','".$f['age']."','".$f['civil_status']."','".$f['occupation']."','".$f['income']."')");

}

/* UPDATE STATUS */
$conn->query("UPDATE pending_registrations SET status='Approved' WHERE id='$id'");


/* SEND EMAIL */

$email = $data['email'];

$subject = "Senior Citizen Registration Approved";

$message = "
Dear ".$data['fname'].",

Your application has been <b>APPROVED</b>.

You are now officially registered as a Senior Citizen.

Please visit the OSCA office to claim your ID.

Thank you.
";

sendEmail($email, $subject, $message);

/* REDIRECT */
header("Location: pending_applications.php");
?>
