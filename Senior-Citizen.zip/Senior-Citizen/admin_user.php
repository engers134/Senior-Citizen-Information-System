<?php
include "session_check.php";
include "config.php";

/* ADD USER */

if(isset($_POST['save'])){

$name = $_POST['name'];
$username = $_POST['username'];
$password = md5($_POST['password']);
$role = $_POST['role'];
$barangay = $_POST['barangay'];

$conn->query("INSERT INTO users (name,username,password,role,barangay_id)
VALUES ('$name','$username','$password','$role','$barangay')");

header("Location: admin_user.php");
exit();

}

/* DELETE USER */

if(isset($_GET['delete'])){

$id = $_GET['delete'];

$conn->query("DELETE FROM users WHERE id='$id'");

header("Location: admin_user.php");
exit();

}
?>
<!DOCTYPE html>
<html>
<head>

<title>User Management</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
.sidebar { min-height:100vh; }
.nav-link:hover { background:#495057; }
</style>

</head>

<body class="bg-light">

<div class="container-fluid">
<div class="row">

<?php include "sidebar.php"; ?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">

<h2 class="mb-4">User Management</h2>

<!-- ADD USER FORM -->
<div class="card shadow-sm mb-4">

<div class="card-header bg-primary text-white">
Add New User
</div>

<div class="card-body">

<form method="POST" class="row g-3">

<div class="col-md-3">
<label class="form-label">Full Name</label>
<input type="text" name="name" class="form-control" required>
</div>

<div class="col-md-2">
<label class="form-label">Username</label>
<input type="text" name="username" class="form-control" required>
</div>

<div class="col-md-2">
<label class="form-label">Password</label>
<input type="password" name="password" class="form-control" required>
</div>

<div class="col-md-2">
<label class="form-label">Role</label>
<select name="role" class="form-select" required>
<option value="">Select Role</option>
<option value="admin">Admin</option>
<option value="staff">Staff</option>
<option value="barangay">Barangay User</option>
</select>
</div>

<div class="col-md-2">
<label class="form-label">Barangay</label>

<select name="barangay" class="form-select">

<option value="">None</option>

<?php
$brgy = $conn->query("SELECT * FROM barangay ORDER BY name ASC");

while($b = $brgy->fetch_assoc()){

echo "<option value='".$b['id']."'>".$b['name']."</option>";

}
?>

</select>

</div>

<div class="col-md-1 d-grid">
<label class="form-label">&nbsp;</label>
<button class="btn btn-success" name="save">
Add
</button>
</div>

</form>

</div>
</div>

<!-- USER LIST -->
<div class="card shadow-sm">

<div class="card-header bg-dark text-white">
System Users
</div>

<div class="card-body table-responsive">

<table class="table table-bordered table-hover">

<thead class="table-dark">

<tr>

<th width="60">ID</th>
<th>Name</th>
<th>Username</th>
<th>Role</th>
<th>Barangay</th>
<th width="120">Action</th>

</tr>

</thead>

<tbody>

<?php

$result = $conn->query("
SELECT users.*, barangay.name as barangay_name
FROM users
LEFT JOIN barangay ON users.barangay_id = barangay.id
ORDER BY users.id DESC
");

while($row = $result->fetch_assoc()){

echo "<tr>";

echo "<td>".$row['id']."</td>";

echo "<td>".$row['name']."</td>";

echo "<td>".$row['username']."</td>";

echo "<td class='text-capitalize'>".$row['role']."</td>";

echo "<td>".$row['barangay_name']."</td>";

echo "<td>

<a href='?delete=".$row['id']."' 
class='btn btn-danger btn-sm'
onclick=\"return confirm('Are you sure you want to delete this user?')\">

Delete

</a>

</td>";

echo "</tr>";

}

?>

</tbody>

</table>

</div>
</div>

</main>
</div>
</div>

</body>
</html>