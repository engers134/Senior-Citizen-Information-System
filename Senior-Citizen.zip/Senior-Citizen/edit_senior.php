<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include "config.php";

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $record_id = $_POST['record_id'];

    $sc_id = $_POST['sc_id'];
    $lname = $_POST['lname'];
    $fname = $_POST['fname'];
    $extension = $_POST['extension'];
    $mname = $_POST['mname'];
    $gender = $_POST['gender'];
    $civil_status = $_POST['civil_status'];
    $birthdate = $_POST['birthdate'];

    // CALCULATE AGE
    $birth = new DateTime($birthdate);
    $today = new DateTime();
    $age = $today->diff($birth)->y;

    $birth_place = $_POST['birth_place'];
    $barangay = $_POST['barangay'];
    $address = $_POST['address'];
    $contact_info = $_POST['contact_info'];
    $email = $_POST['email'];
    $pension = $_POST['pension'];
    $monthly_pension = $_POST['monthly_pension'];
    $status = $_POST['status'];
    $education = $_POST['education'];
    $occupation = $_POST['occupation'];
    $em_person = $_POST['em_person'];
    $em_number = $_POST['em_number'];
    $em_address = $_POST['em_address'];
    if($status == "Deceased"){
    $date_of_death = $_POST['date_of_death'];
}else{
    $date_of_death = NULL;
}

    // UPDATE SENIOR CITIZEN
    $conn->query("UPDATE senior_citizens SET
        sc_id='$sc_id',
        last_name='$lname',
        first_name='$fname',
        extension='$extension',
        middle_name='$mname',
        gender='$gender',
        civil_status='$civil_status',
        birthdate='$birthdate',
        age='$age',
        birth_place='$birth_place',
        barangay_id='$barangay',
        address='$address',
        contact_info='$contact_info',
        email='$email',
        pension_status='$pension',
        monthly_pension='$monthly_pension',
        status='$status',
        education='$education',
        occupation='$occupation',
        emergency_person='$em_person',
        emergency_number='$em_number',
        emergency_address='$em_address',
        date_of_death='$date_of_death'
        WHERE id='$record_id'
    ");

    /* ===============================
       UPDATE FAMILY MEMBERS
    =============================== */

    if(isset($_POST['family_name'])){

        for($i=0; $i<count($_POST['family_name']); $i++){

            $family_id = $_POST['family_id'][$i];
            $name = $_POST['family_name'][$i];
            $relationship = $_POST['relationship'][$i];
            $f_age = $_POST['family_age'][$i];
            $civil = $_POST['family_civil'][$i];
            $f_occupation = $_POST['family_occupation'][$i];
            $income = $_POST['family_income'][$i];

            if($name != ""){

                // UPDATE EXISTING FAMILY MEMBER
                if($family_id != ""){

                    $conn->query("UPDATE family_composition SET
                        name='$name',
                        relationship='$relationship',
                        age='$f_age',
                        civil_status='$civil',
                        occupation='$f_occupation',
                        income='$income'
                        WHERE id='$family_id'");

                }

                // INSERT NEW FAMILY MEMBER
                else{

                    $conn->query("INSERT INTO family_composition
                    (senior_id,name,relationship,age,civil_status,occupation,income)
                    VALUES
                    ('$record_id','$name','$relationship','$f_age','$civil','$f_occupation','$income')");

                }

            }

        }

    }

    // REDIRECT
if($conn->affected_rows > 0){
    header("Location: senior_citizen.php?updated=1");
} else {
    header("Location: senior_citizen.php?updated=0");
}
    exit();
}
?>

