
document.addEventListener("DOMContentLoaded", function(){

/* =========================================
SHOW DATE OF DEATH WHEN STATUS = DECEASED
========================================= */

function toggleDeathField(){

const statusField = document.getElementById("statusField");
const deathDiv = document.getElementById("deathDateDiv");
const deathInput = document.getElementById("date_of_death");

if(!statusField) return;

if(statusField.value === "Deceased"){

deathDiv.style.display = "block";
deathInput.required = true;

}else{

deathDiv.style.display = "none";
deathInput.required = false;
deathInput.value = "";

}

}

/* detect status change even inside modal */

document.addEventListener("change", function(e){

if(e.target && e.target.id === "statusField"){
toggleDeathField();
}

});



/* =========================================
VIEW SENIOR CITIZEN
========================================= */

document.querySelectorAll(".viewBtn").forEach(function(button){

button.addEventListener("click", function(){

console.log("EMAIL:", this.dataset.email); 

let seniorID = this.dataset.id;

document.getElementById("v_scid").innerText = this.dataset.scid;

document.getElementById("v_fullname").innerText =
this.dataset.lname + ", " +
this.dataset.fname + " " +
(this.dataset.extension ? this.dataset.extension + " " : "") +
this.dataset.mname;

document.getElementById("v_gender").innerText = this.dataset.gender;
document.getElementById("v_civil").innerText = this.dataset.civil;
document.getElementById("v_age").innerText = this.dataset.age;
document.getElementById("v_birthdate").innerText = this.dataset.birthdate;
document.getElementById("v_birthplace").innerText = this.dataset.birthplace;
document.getElementById("v_barangay").innerText = this.dataset.barangay;
document.getElementById("v_status").innerText = this.dataset.status;
if(this.dataset.status === "Deceased"){
    document.getElementById("v_dod").innerText =
        this.dataset.dod ? new Date(this.dataset.dod).toLocaleDateString() : "Not Recorded";
}else{
    document.getElementById("v_dod").innerText = "N/A";
}
document.getElementById("v_encoder").innerText = this.dataset.encoder;

document.getElementById("v_encoder").innerText =
this.dataset.encoder || "Unknown User";

let date = this.dataset.date;

if(date){
    document.getElementById("v_date").innerText =
    new Date(date).toLocaleString();
}else{
    document.getElementById("v_date").innerText = "No record";
}
document.getElementById("v_education").innerText = this.dataset.education;
document.getElementById("v_occupation").innerText = this.dataset.occupation;
document.getElementById("v_address").innerText = this.dataset.address;
document.getElementById("v_contact").innerText = this.dataset.contact;
document.getElementById("v_email").innerText =
(this.dataset.email && this.dataset.email !== "null" && this.dataset.email !== "")
? this.dataset.email
: "No Email";
document.getElementById("v_pension").innerText = this.dataset.pension;
document.getElementById("v_monthly").innerText = this.dataset.monthly;
document.getElementById("v_emperson").innerText = this.dataset.emperson;
document.getElementById("v_emnumber").innerText = this.dataset.emnumber;
document.getElementById("v_emaddress").innerText = this.dataset.emaddress;

/* LOAD FAMILY COMPOSITION */

fetch("get_family.php?senior_id=" + seniorID)

.then(response => response.json())

.then(data => {

let table = document.getElementById("familyTableBody");

table.innerHTML = "";

data.forEach(function(row){

table.innerHTML += `
<tr>
<td>${row.name}</td>
<td>${row.relationship}</td>
<td>${row.age}</td>
<td>${row.civil_status}</td>
<td>${row.occupation}</td>
<td>${row.income}</td>
</tr>
`;

});

});

new bootstrap.Modal(document.getElementById("viewModal")).show();

});

});

/* =========================================
EDIT SENIOR CITIZEN
========================================= */

document.querySelectorAll(".editBtn").forEach(function(button){

button.addEventListener("click", function(){

const form = document.querySelector("#seniorModal form");

document.querySelector(".modal-title").innerText = "Update Senior Citizen";

form.action = "edit_senior.php";

form.querySelector("input[name='record_id']").value = this.dataset.id;

form.querySelector("input[name='sc_id']").value = this.dataset.scid;
form.querySelector("input[name='lname']").value = this.dataset.lname;
form.querySelector("input[name='fname']").value = this.dataset.fname;
form.querySelector("select[name='extension']").value = this.dataset.extension;
form.querySelector("input[name='mname']").value = this.dataset.mname;
form.querySelector("select[name='gender']").value = this.dataset.gender;
form.querySelector("select[name='civil_status']").value = this.dataset.civil;
form.querySelector("input[name='birthdate']").value = this.dataset.birthdate;
form.querySelector("input[name='birth_place']").value = this.dataset.birthplace;
form.querySelector("select[name='barangay']").value = this.dataset.barangay;
form.querySelector("input[name='address']").value = this.dataset.address;
form.querySelector("input[name='contact_info']").value = this.dataset.contact;
form.querySelector("input[name='email']").value = this.dataset.email;
form.querySelector("select[name='pension']").value = this.dataset.pension;
form.querySelector("input[name='monthly_pension']").value = this.dataset.monthly;
form.querySelector("select[name='status'] option[value='Deceased']").disabled = false;
form.querySelector("select[name='status']").value = this.dataset.status;
document.getElementById("date_of_death").value = this.dataset.dod;
toggleDeathField();
document.getElementById("statusField").addEventListener("change", toggleDeathField);
form.querySelector("input[name='education']").value = this.dataset.education;
form.querySelector("input[name='occupation']").value = this.dataset.occupation;
form.querySelector("input[name='em_person']").value = this.dataset.emperson;
form.querySelector("input[name='em_number']").value = this.dataset.emnumber;
form.querySelector("input[name='em_address']").value = this.dataset.emaddress;

/* LOAD FAMILY MEMBERS */

fetch("get_family.php?senior_id=" + this.dataset.id)

.then(response => response.json())

.then(data => {

let table = document.getElementById("familyBody");

table.innerHTML = "";

data.forEach(function(row){

table.innerHTML += `
<tr>

<td>
<input type="hidden" name="family_id[]" value="${row.id}">
<input type="text" name="family_name[]" value="${row.name}" class="form-control">
</td>

<td>
<input type="text" name="relationship[]" value="${row.relationship}" class="form-control">
</td>

<td>
<input type="number" name="family_age[]" value="${row.age}" class="form-control">
</td>

<td>
<select name="family_civil[]" class="form-select">
<option ${row.civil_status=="Single"?"selected":""}>Single</option>
<option ${row.civil_status=="Married"?"selected":""}>Married</option>
<option ${row.civil_status=="Widowed"?"selected":""}>Widowed</option>
</select>
</td>

<td>
<input type="text" name="family_occupation[]" value="${row.occupation}" class="form-control">
</td>

<td>
<input type="number" name="family_income[]" value="${row.income}" class="form-control">
</td>

<td>
<button type="button" class="btn btn-danger removeRow">X</button>
</td>

</tr>
`;

});

});

new bootstrap.Modal(document.getElementById("seniorModal")).show();

});

});

/* =========================================
ADD NEW SENIOR CITIZEN
========================================= */

document.getElementById("addBtn").addEventListener("click", function(){

document.querySelector(".modal-title").innerText = "Add Senior Citizen";

const form = document.querySelector("#seniorModal form");

form.action = "add_senior.php";

form.reset();

form.querySelector("select[name='status']").value = "Active";

form.querySelector("select[name='status'] option[value='Deceased']").disabled = true;;

document.getElementById("deathDateDiv").style.display = "none";
document.getElementById("date_of_death").required = false;

document.getElementById("statusField").addEventListener("change", toggleDeathField);

form.querySelector("input[name='record_id']").value = "";

/* CLEAR FAMILY TABLE */

document.getElementById("familyBody").innerHTML = `
<tr>

<td>
<input type="hidden" name="family_id[]">
<input type="text" name="family_name[]" class="form-control">
</td>

<td>
<input type="text" name="relationship[]" class="form-control">
</td>

<td>
<input type="number" name="family_age[]" class="form-control">
</td>

<td>
<select name="family_civil[]" class="form-select">
<option>Single</option>
<option>Married</option>
<option>Widowed</option>
</select>
</td>

<td>
<input type="text" name="family_occupation[]" class="form-control">
</td>

<td>
<input type="number" name="family_income[]" class="form-control">
</td>

<td>
<button type="button" class="btn btn-danger removeRow">X</button>
</td>

</tr>
`;

new bootstrap.Modal(document.getElementById("seniorModal")).show();

});

/* =========================================
ADD FAMILY ROW
========================================= */

document.getElementById("addFamilyRow").addEventListener("click", function(){

let row = `
<tr>

<td><input type="text" name="family_name[]" class="form-control"></td>
<td><input type="text" name="relationship[]" class="form-control"></td>
<td><input type="number" name="family_age[]" class="form-control"></td>

<td>
<select name="family_civil[]" class="form-select">
<option>Single</option>
<option>Married</option>
<option>Widowed</option>
</select>
</td>

<td><input type="text" name="family_occupation[]" class="form-control"></td>

<td><input type="number" name="family_income[]" class="form-control"></td>

<td>
<button type="button" class="btn btn-danger removeRow">X</button>
</td>

</tr>
`;

document.getElementById("familyBody").insertAdjacentHTML("beforeend", row);

});

/* =========================================
REMOVE FAMILY ROW
========================================= */

document.addEventListener("click", function(e){

if(e.target.classList.contains("removeRow")){
e.target.closest("tr").remove();
}

});

/* =========================================
SAVE CONFIRMATION MODAL
========================================= */
const saveBtn = document.getElementById("saveBtn");
const confirmSaveBtn = document.getElementById("confirmSaveBtn");
const confirmMessage = document.getElementById("confirmMessage");

if(saveBtn){

saveBtn.addEventListener("click", function(){

const form = document.querySelector("#seniorModal form");

/* CHECK REQUIRED FIELDS FIRST */

if(!form.checkValidity()){
form.reportValidity();
return;
}

/* CHANGE MESSAGE FOR ADD OR EDIT */

if(form.action.includes("edit_senior.php")){
confirmMessage.innerHTML =
"Are you sure you want to update this senior citizen's details?<br>Please review the information before confirming.";
}else{
confirmMessage.innerHTML =
"Are you sure you want to add this senior citizen record?";
}

var confirmModal = new bootstrap.Modal(
document.getElementById("confirmSaveModal")
);

confirmModal.show();

});

}

if(confirmSaveBtn){

confirmSaveBtn.addEventListener("click", function(){

const form = document.querySelector("#seniorModal form");

if(!form.checkValidity()){
form.reportValidity();
return;
}

form.requestSubmit();

});

}

});

/* Auto uppercase */
document.addEventListener("input", function(e){

if(
e.target.name === "lname" ||
e.target.name === "fname" ||
e.target.name === "mname"
){
e.target.value = e.target.value.toUpperCase();
}

});