<!-- SIDEBAR -->
<nav class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse" id="sidebarMenu">
  <div class="position-sticky pt-3">

    <h5 class="text-white text-center mb-4 px-3">
      Senior Citizen<br>Management System
    </h5>

    <ul class="nav flex-column">

      <li class="nav-item">
        <a class="nav-link text-white" href="dashboard.php">
          Dashboard
        </a>
      </li>

      <?php if($_SESSION['role'] != 'barangay'){ ?>

<li class="nav-item">
<a class="nav-link text-white" href="barangay.php">
Barangay
</a>
</li>

<?php } ?>



      <li class="nav-item">
<a class="nav-link text-white" href="senior_citizen.php">
Senior Citizen
</a>
</li>



<li class="nav-item">
<a class="nav-link" href="pending_applications.php">Pending Applications</a>
</li>


      <?php if($_SESSION['role'] == 'admin'){ ?>

<li class="nav-item">
<a class="nav-link text-white" href="barangay_user.php">
Barangay Users
</a>
</li>

<?php } ?>

     <?php if($_SESSION['role'] == 'admin'){ ?>

<li class="nav-item">
<a class="nav-link text-white" href="admin_user.php">
Admin Users
</a>
</li>

<?php } ?>

      <?php if($_SESSION['role'] != 'barangay'){ ?>

<li class="nav-item">
<a class="nav-link text-white" href="reports.php">
Reports
</a>
</li>

<?php } ?>
<li class="nav-item">
<a class="nav-link text-white" href="logout.php">
Logout
</a>
</li>
      
    </ul>
  </div>
</nav>