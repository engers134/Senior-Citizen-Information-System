<?php
include "session_check.php";
include "config.php";
?>

<?php
$barangay = $conn->query("SELECT COUNT(*) as total FROM barangay")->fetch_assoc();
$senior = $conn->query("SELECT COUNT(*) as total FROM senior_citizens")->fetch_assoc();

$pension_yes = $conn->query("SELECT COUNT(*) as total FROM senior_citizens WHERE pension_status='With Pension'")->fetch_assoc();
$pension_no = $conn->query("SELECT COUNT(*) as total FROM senior_citizens WHERE pension_status='Without Pension'")->fetch_assoc();

$barangay_chart = $conn->query("
SELECT barangay.name, COUNT(senior_citizens.id) as total
FROM senior_citizens
LEFT JOIN barangay ON senior_citizens.barangay_id = barangay.id
GROUP BY barangay.name
");

$barangay_names = [];
$barangay_totals = [];

while($row = $barangay_chart->fetch_assoc()){
    $barangay_names[] = $row['name'];
    $barangay_totals[] = $row['total'];
}

$male = $conn->query("SELECT COUNT(*) as total FROM senior_citizens WHERE gender='Male'")->fetch_assoc();
$female = $conn->query("SELECT COUNT(*) as total FROM senior_citizens WHERE gender='Female'")->fetch_assoc();

$active = $conn->query("SELECT COUNT(*) as total FROM senior_citizens WHERE status='Active'")->fetch_assoc();
$deceased = $conn->query("SELECT COUNT(*) as total FROM senior_citizens WHERE status='Deceased'")->fetch_assoc();
?>

<!DOCTYPE html>

<html>
<head>
<title>Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { font-size:.875rem; }
.sidebar { min-height:100vh; }
.nav-link:hover { background-color:#495057; }
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>

<div class="container-fluid">
<div class="row">

<?php include "sidebar.php"; ?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4 bg-light">

<h2 class="mb-4">Admin Dashboard</h2>

<div class="row g-4">

<div class="col-md-3">
<div class="card shadow-sm border-0 text-center">
<div class="card-body">
<h6 class="text-muted">Total Barangays</h6>
<h2 class="fw-bold text-primary">
<?php echo $barangay['total']; ?>
</h2>
</div>
</div>
</div>

<div class="col-md-3">
<div class="card shadow-sm border-0 text-center">
<div class="card-body">
<h6 class="text-muted">Total Senior Citizens</h6>
<h2 class="fw-bold text-success">
<?php echo $senior['total']; ?>
</h2>
</div>
</div>
</div>

<div class="col-md-3">
<div class="card shadow-sm border-0 text-center">
<div class="card-body">
<h6 class="text-muted">Active Seniors</h6>
<h2 class="fw-bold text-info">
<?php echo $active['total']; ?>
</h2>
</div>
</div>
</div>

<div class="col-md-3">
<div class="card shadow-sm border-0 text-center">
<div class="card-body">
<h6 class="text-muted">Deceased Seniors</h6>
<h2 class="fw-bold text-danger">
<?php echo $deceased['total']; ?>
</h2>
</div>
</div>
</div>

<div class="col-md-3">
<div class="card shadow-sm border-0 text-center">
<div class="card-body">
<h6 class="text-muted">With Pension</h6>
<h2 class="fw-bold text-success">
<?php echo $pension_yes['total']; ?>
</h2>
</div>
</div>
</div>

<div class="col-md-3">
<div class="card shadow-sm border-0 text-center">
<div class="card-body">
<h6 class="text-muted">Without Pension</h6>
<h2 class="fw-bold text-warning">
<?php echo $pension_no['total']; ?>
</h2>
</div>
</div>
</div>

<div class="col-md-3">
<div class="card shadow-sm border-0 text-center">
<div class="card-body">
<h6 class="text-muted">Male Seniors</h6>
<h2 class="fw-bold text-dark">
<?php echo $male['total']; ?>
</h2>
</div>
</div>
</div>

<div class="col-md-3">
<div class="card shadow-sm border-0 text-center">
<div class="card-body">
<h6 class="text-muted">Female Seniors</h6>
<h2 class="fw-bold text-danger">
<?php echo $female['total']; ?>
</h2>
</div>
</div>
</div>

</div>

<div class="card shadow-sm mt-4">
<div class="card-body">

<h5 class="mb-3">Senior Citizens per Barangay</h5>

<canvas id="barangayChart"></canvas>

</div>
</div>

<?php
$recent = $conn->query("
SELECT senior_citizens.*, barangay.name AS barangay_name
FROM senior_citizens
LEFT JOIN barangay ON senior_citizens.barangay_id = barangay.id
ORDER BY id DESC
LIMIT 5
");
?>

<div class="card shadow-sm mt-4">
<div class="card-body">

<h5 class="mb-3">Recently Registered Seniors</h5>

<table class="table table-bordered">

<thead class="table-dark">
<tr>
<th>ID</th>
<th>Name</th>
<th>Barangay</th>
<th>Status</th>
</tr>
</thead>

<tbody>

<?php while($row = $recent->fetch_assoc()){ ?>

<tr>
<td><?php echo $row['sc_id']; ?></td>
<td><?php echo $row['last_name'].", ".$row['first_name']; ?></td>
<td><?php echo $row['barangay_name']; ?></td>
<td><?php echo $row['status']; ?></td>
</tr>

<?php } ?>

</tbody>

</table>

</div>
</div>

</main>
</div>
</div>

<script>

var ctx = document.getElementById('barangayChart').getContext('2d');

var barangayChart = new Chart(ctx, {
type: 'bar',
data: {
labels: <?php echo json_encode($barangay_names); ?>,
datasets: [{
label: 'Senior Citizens',
data: <?php echo json_encode($barangay_totals); ?>,
backgroundColor: 'rgba(54,162,235,0.7)'
}]
},
options: {
responsive:true,
plugins:{
legend:{display:false}
},
scales:{
y:{
beginAtZero:true
}
}
}
});

</script>

</body>
</html>



