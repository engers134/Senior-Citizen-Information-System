<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

function sendEmail($to, $subject, $message){

    $mail = new PHPMailer(true);

    try {

        // SERVER SETTINGS
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;

        // YOUR GMAIL ACCOUNT
        $mail->Username   = 'jomags1001@gmail.com';
        $mail->Password   = 'xxwmbsnqzopjtpvz'; // App Password

        // 🔥 USE SSL (MORE STABLE)
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = 465;

        // ⏱ TIMEOUT FIX
        $mail->Timeout = 10;

        // OPTIONAL DEBUG (TURN OFF AFTER TEST)
        // $mail->SMTPDebug = 2;

        // SENDER
        $mail->setFrom('jomags1001@gmail.com', 'OSCA Orion');

        // RECEIVER
        $mail->addAddress($to);

        // EMAIL CONTENT
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $message;

        // SEND
        $mail->send();

        return true;

    } catch (Exception $e) {

        // ❗ DO NOT STOP SYSTEM
        return false;
    }
}
?>