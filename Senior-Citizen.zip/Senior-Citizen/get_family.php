<?php
include "config.php";

$senior_id = $_GET['senior_id'];

$result = $conn->query("SELECT * FROM family_composition WHERE senior_id='$senior_id'");

$data = [];

while($row = $result->fetch_assoc()){
    $data[] = $row;
}

echo json_encode($data);
?>