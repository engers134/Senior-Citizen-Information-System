<?php
include "session_check.php";
include "config.php";
?>

<?php
// DELETE
if(isset($_GET['delete'])){
    $delete_id = $_GET['delete'];
    $conn->query("DELETE FROM barangay WHERE id='$delete_id'");
    header("Location: barangay.php");
    exit();
}

// EDIT
$edit_data = array();
if(isset($_GET['edit'])){
    $edit_id = $_GET['edit'];
    $edit_result = $conn->query("SELECT * FROM barangay WHERE id='$edit_id'");
    $edit_data = $edit_result->fetch_assoc();
}

// SAVE OR UPDATE
if(isset($_POST['save'])){

    $record_id = $_POST['record_id'];
    $name = $_POST['name'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $person = $_POST['person'];
    $person_contact = $_POST['person_contact'];

    if($record_id == ""){
        $conn->query("INSERT INTO barangay 
        (name, contact, email, contact_person, contact_person_number)
        VALUES ('$name','$contact','$email','$person','$person_contact')");
    } else {
        $conn->query("UPDATE barangay SET
        name='$name',
        contact='$contact',
        email='$email',
        contact_person='$person',
        contact_person_number='$person_contact'
        WHERE id='$record_id'");
    }

    header("Location: barangay.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Barangay Management</title>

<!-- Bootstrap 5 -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
.sidebar {
    min-height: 100vh;
}
.nav-link:hover {
    background-color: #495057;
}
</style>

</head>
<body class="bg-light">

<div class="container-fluid">
<div class="row">

<?php include "sidebar.php"; ?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">

<h2 class="mb-4">Barangay Information</h2>

<!-- FORM -->
<div class="card shadow-sm mb-4">
<div class="card-body">

<form method="POST" class="row g-3">

<input type="hidden" name="record_id"
value="<?php echo isset($edit_data['id']) ? $edit_data['id'] : ''; ?>">

<div class="col-md-4">
<input type="text" name="name" class="form-control"
placeholder="Barangay Name" required
value="<?php echo isset($edit_data['name']) ? $edit_data['name'] : ''; ?>">
</div>

<div class="col-md-4">
<input type="text" name="contact" class="form-control"
placeholder="Contact Number" required
value="<?php echo isset($edit_data['contact']) ? $edit_data['contact'] : ''; ?>">
</div>

<div class="col-md-4">
<input type="email" name="email" class="form-control"
placeholder="Email Address" required
value="<?php echo isset($edit_data['email']) ? $edit_data['email'] : ''; ?>">
</div>

<div class="col-md-6">
<input type="text" name="person" class="form-control"
placeholder="Contact Person Name" required
value="<?php echo isset($edit_data['contact_person']) ? $edit_data['contact_person'] : ''; ?>">
</div>

<div class="col-md-6">
<input type="text" name="person_contact" class="form-control"
placeholder="Contact Person Number" required
value="<?php echo isset($edit_data['contact_person_number']) ? $edit_data['contact_person_number'] : ''; ?>">
</div>

<div class="col-12">
<button type="submit" name="save" class="btn btn-success">
<?php
if(isset($edit_data['id'])){
    echo "Update Barangay";
}else{
    echo "Save Barangay";
}
?>
</button>
</div>

</form>

</div>
</div>

<!-- TABLE -->
<div class="card shadow-sm">
<div class="card-body table-responsive">

<table class="table table-bordered table-hover">
<thead class="table-dark">
<tr>
<th>#</th>
<th>Name</th>
<th>Contact</th>
<th>Email</th>
<th>Contact Person</th>
<th>Person Number</th>
<th>Actions</th>
</tr>
</thead>
<tbody>

<?php
$result = $conn->query("SELECT * FROM barangay ORDER BY name ASC");
$count = 1;

while($row = $result->fetch_assoc()){
echo "<tr>";
echo "<td>".$count++."</td>";
echo "<td>".$row['name']."</td>";
echo "<td>".$row['contact']."</td>";
echo "<td>".$row['email']."</td>";
echo "<td>".$row['contact_person']."</td>";
echo "<td>".$row['contact_person_number']."</td>";
echo "<td>
<a href='?edit=".$row['id']."' class='btn btn-sm btn-warning'>Edit</a>
<a href='?delete=".$row['id']."' class='btn btn-sm btn-danger'
onclick=\"return confirm('Delete this barangay?')\">Delete</a>
</td>";
echo "</tr>";
}
?>

</tbody>
</table>

</div>
</div>

</main>
</div>
</div>

</body>
</html>