

<?php if(isset($_GET['success'])): ?>
<div class="alert alert-success text-center">
Application submitted successfully! Please wait for approval.
</div>
<?php endif; ?>


<!DOCTYPE html>

<html>
<head>

<title>Senior Citizen Registration</title>

<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
background:#f5f7fa;
}

.header{
background:#0d6efd;
color:white;
padding:30px;
text-align:center;
}

.section{
padding:40px 20px;
}

</style>

</head>

<body>

<div class="header">

<h2>Senior Citizen Registration</h2>
<p>Municipality of Orion</p>

<a href="index.php" class="btn btn-light btn-sm">
Back to Home
</a>

</div>

<div class="container section">

<div class="card shadow">

<div class="card-body">

<h4 class="mb-4">Application Form</h4>

<form method="POST" action="submit_registration.php" class="row g-3">

<!-- NAME -->

<div class="col-md-3">
<label class="form-label">Last Name</label>
<input type="text" name="lname" class="form-control" required>
</div>

<div class="col-md-3">
<label class="form-label">First Name</label>
<input type="text" name="fname" class="form-control" required>
</div>

<div class="col-md-2">
<label class="form-label">Extension</label>
<select name="extension" class="form-select">
<option value="">N/A</option>
<option value="Jr.">Jr.</option>
<option value="Sr.">Sr.</option>
<option value="II">II</option>
<option value="III">III</option>
</select>
</div>

<div class="col-md-4">
<label class="form-label">Middle Name</label>
<input type="text" name="mname" class="form-control">
</div>

<div class="col-md-3">
<label class="form-label">Gender</label>
<select name="gender" class="form-select" required>
<option value="">Select Gender</option>
<option>Male</option>
<option>Female</option>
</select>
</div>

<div class="col-md-3">
<label class="form-label">Civil Status</label>
<select name="civil_status" class="form-select" required>
<option value="">Select Civil Status</option>
<option>Single</option>
<option>Married</option>
<option>Widowed</option>
<option>Separated</option>
</select>
</div>

<div class="col-md-3">
<label class="form-label">Date of Birth</label>
<input type="date" name="birthdate" class="form-control" required>
</div>

<div class="col-md-3">
<label class="form-label">Place of Birth</label>
<input type="text" name="birth_place" class="form-control" required>
</div>

<!-- ADDRESS -->

<div class="col-md-4">
<label class="form-label">Barangay</label>

<select name="barangay_id" class="form-select" required>

<option value="">Select Barangay</option>

<?php
include "config.php";

$brgy = $conn->query("SELECT * FROM barangay ORDER BY name ASC");

while($row = $brgy->fetch_assoc()){
    echo "<option value='".$row['id']."'>".$row['name']."</option>";
}
?>

</select>

</div>

<div class="col-md-8">
<label class="form-label">Complete Address</label>
<input type="text" name="address" class="form-control" required>
</div>

<div class="col-md-6">
<label class="form-label">Contact Number</label>
<input type="text" name="contact_info" class="form-control" required>
</div>


<div class="col-md-6">
<label class="form-label">Email Address</label>
<input type="email" name="email" class="form-control" required>
</div>

<div class="col-md-3">
<label class="form-label">Pension Status</label>
<select name="pension_status" class="form-select">
<option value="">Select</option>
<option>With Pension</option>
<option>Without Pension</option>
</select>
</div>

<div class="col-md-3">
<label class="form-label">Monthly Pension</label>
<input type="number" name="monthly_pension" class="form-control">
</div>

<hr>

<h5>Educational and Work Information</h5>

<div class="col-md-6">
<label class="form-label">Educational Attainment</label>
<input type="text" name="education" class="form-control">
</div>

<div class="col-md-6">
<label class="form-label">Occupation</label>
<input type="text" name="occupation" class="form-control">
</div>

<hr>

<h5>Family Composition</h5>

<table class="table table-bordered" id="familyTable">

<thead class="table-secondary">
<tr>
<th>Name</th>
<th>Relationship</th>
<th>Age</th>
<th>Civil Status</th>
<th>Occupation</th>
<th>Income</th>
<th>Action</th>
</tr>
</thead>

<tbody id="familyBody">

<tr>

<td>
<input type="text" name="family_name[]" class="form-control">
</td>

<td>
<input type="text" name="relationship[]" class="form-control">
</td>

<td>
<input type="number" name="family_age[]" class="form-control">
</td>

<td>
<select name="family_civil[]" class="form-select">
<option>Single</option>
<option>Married</option>
<option>Widowed</option>
</select>
</td>

<td>
<input type="text" name="family_occupation[]" class="form-control">
</td>

<td>
<input type="number" name="family_income[]" class="form-control">
</td>

<td>
<button type="button" class="btn btn-danger removeRow">X</button>
</td>

</tr>

</tbody>
</table>

<button type="button" class="btn btn-primary" id="addFamilyRow">
+ Add Family Member
</button>

<hr>

<h5>Emergency Contact Information</h5>

<div class="col-md-4">
<label class="form-label">Contact Person</label>
<input type="text" name="em_person" class="form-control" required>
</div>

<div class="col-md-4">
<label class="form-label">Contact Number</label>
<input type="text" name="em_number" class="form-control" required>
</div>

<div class="col-md-4">
<label class="form-label">Address</label>
<input type="text" name="em_address" class="form-control" required>
</div>

<div class="col-12 text-end">

<button type="submit" class="btn btn-primary btn-lg">
Submit Application
</button>

</div>

</form>

</div>

</div>

</div>

<script>

document.getElementById("addFamilyRow").addEventListener("click", function(){

let row = `
<tr>

<td><input type="text" name="family_name[]" class="form-control"></td>
<td><input type="text" name="relationship[]" class="form-control"></td>
<td><input type="number" name="family_age[]" class="form-control"></td>

<td>
<select name="family_civil[]" class="form-select">
<option>Single</option>
<option>Married</option>
<option>Widowed</option>
</select>
</td>

<td><input type="text" name="family_occupation[]" class="form-control"></td>

<td><input type="number" name="family_income[]" class="form-control"></td>

<td>
<button type="button" class="btn btn-danger removeRow">X</button>
</td>

</tr>
`;

document.getElementById("familyBody").insertAdjacentHTML("beforeend", row);

});


document.addEventListener("click", function(e){

if(e.target.classList.contains("removeRow")){
e.target.closest("tr").remove();
}

});

</script>

</body>
</html>
