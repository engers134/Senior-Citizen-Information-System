<?php
include "session_check.php";

if($_SESSION['role'] == 'barangay'){
    header("Location: senior_citizen.php");
    exit();
}
?>


<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include "config.php";

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $sc_id = $_POST['sc_id'];
    $lname = $_POST['lname'];
    $fname = $_POST['fname'];
    $extension = $_POST['extension'];
    $mname = $_POST['mname'];
    $gender = $_POST['gender'];
    $civil_status = $_POST['civil_status'];
    $birthdate = $_POST['birthdate'];

    // CALCULATE AGE
    $birth = new DateTime($birthdate);
    $today = new DateTime();
    $age = $today->diff($birth)->y;

    $birth_place = $_POST['birth_place'];
    $barangay = $_POST['barangay'];
    $address = $_POST['address'];
    $contact_info = $_POST['contact_info'];
    $email = $_POST['email'];
    $pension = $_POST['pension'];
    $monthly_pension = $_POST['monthly_pension'];
    $status = $_POST['status'];
    $education = $_POST['education'];
    $occupation = $_POST['occupation'];
    $em_person = $_POST['em_person'];
    $em_number = $_POST['em_number'];
    $em_address = $_POST['em_address'];
    $date_of_death = isset($_POST['date_of_death']) ? $_POST['date_of_death'] : NULL;
    $encoded_by = $_SESSION['user_id'];

    // INSERT SENIOR CITIZEN
    $sql = "INSERT INTO senior_citizens
(sc_id,last_name,first_name,extension,middle_name,gender,civil_status,birthdate,age,birth_place,
barangay_id,address,contact_info,email,pension_status,monthly_pension,status,
emergency_person,emergency_number,emergency_address,education,occupation,date_of_death,encoded_by)

VALUES
('$sc_id','$lname','$fname','$extension','$mname','$gender','$civil_status','$birthdate','$age','$birth_place',
'$barangay','$address','$contact_info','$email','$pension','$monthly_pension','$status',
'$em_person','$em_number','$em_address','$education','$occupation','$date_of_death','$encoded_by')";

    $conn->query($sql);

    // GET LAST INSERTED ID
    $senior_id = $conn->insert_id;

    // INSERT FAMILY COMPOSITION
    if(isset($_POST['family_name'])){

        for($i=0; $i<count($_POST['family_name']); $i++){

            $name = $_POST['family_name'][$i];
            $relationship = $_POST['relationship'][$i];
            $f_age = $_POST['family_age'][$i];
            $civil = $_POST['family_civil'][$i];
            $f_occupation = $_POST['family_occupation'][$i];
            $income = $_POST['family_income'][$i];

            if($name != ""){

                $conn->query("INSERT INTO family_composition
                (senior_id,name,relationship,age,civil_status,occupation,income)
                VALUES
                ('$senior_id','$name','$relationship','$f_age','$civil','$f_occupation','$income')");

            }

        }

    }

    // REDIRECT
    if($senior_id){
        header("Location: senior_citizen.php?add=1");
    } else {
        header("Location: senior_citizen.php?add=0");
    }

    exit();
}
?>

